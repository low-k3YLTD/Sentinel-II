/**
 * Unified Security Module - Integrates all security detection systems
 * Provides a comprehensive threat assessment across all domains
 */

import {
  simulateNetworkScan,
  detectMitmAttacks,
  detectArpSpoofing,
  assessNetworkSecurity,
  NetworkThreat,
  NetworkDevice,
} from './network-scanner';

import {
  detectImsiCatcher,
  calculateImsiThreatLevel,
  generateImsiRecommendations,
  ImsiThreatIndicator,
  CellularSignal,
} from './imsi-detector';

import {
  anonymizeImage,
  RealTimeAnonymizer,
  AnonymizationConfig,
} from './facial-anonymizer';

import {
  assessTrackerThreat,
  identifyTrackerType,
  calculateTrackerRiskScore,
  StalkerDetection,
  TrackerProfile,
  GeoLocation,
  MovementPattern,
} from './tracker-detector';

export interface UnifiedSecurityStatus {
  overallThreatLevel: 'safe' | 'low' | 'medium' | 'high' | 'critical';
  lastAssessmentTime: number;
  threatSummary: {
    networkThreats: number;
    imsiThreats: number;
    trackerThreats: number;
    totalThreats: number;
  };
  recommendations: string[];
  details: {
    network: NetworkThreatDetails;
    cellular: CellularThreatDetails;
    trackers: TrackerThreatDetails;
    privacy: PrivacyDetails;
  };
}

export interface NetworkThreatDetails {
  devicesScanned: number;
  threatsDetected: NetworkThreat[];
  criticalServices: string[];
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
}

export interface CellularThreatDetails {
  currentSignal: CellularSignal | null;
  threatsDetected: ImsiThreatIndicator[];
  threatLevel: 'safe' | 'low' | 'medium' | 'high' | 'critical';
  recommendations: string[];
}

export interface TrackerThreatDetails {
  trackersDetected: number;
  suspiciousTrackers: TrackerProfile[];
  stalkerDetections: StalkerDetection[];
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
}

export interface PrivacyDetails {
  facesAnonymized: number;
  privacyScore: number; // 0-100
  exposureRisk: 'low' | 'medium' | 'high';
}

/**
 * Unified Security Assessment Engine
 */
export class UnifiedSecurityAssessment {
  private networkDevices: NetworkDevice[] = [];
  private cellularSignals: CellularSignal[] = [];
  private trackers: TrackerProfile[] = [];
  private userLocations: GeoLocation[] = [];
  private userMovementPattern: MovementPattern | null = null;
  private anonymizer: RealTimeAnonymizer | null = null;
  
  constructor() {
    // Initialize with default anonymization config
    const defaultConfig: AnonymizationConfig = {
      method: 'blur',
      blurIntensity: 50,
      expandBoundingBox: 10,
    };
    this.anonymizer = new RealTimeAnonymizer(defaultConfig);
  }
  
  /**
   * Perform comprehensive security assessment
   */
  async assessSecurity(): Promise<UnifiedSecurityStatus> {
    const startTime = Date.now();
    
    // Run all security scans in parallel
    const [networkThreats, cellularThreats, trackerThreats, privacyStatus] = await Promise.all([
      this.assessNetworkSecurity(),
      this.assessCellularSecurity(),
      this.assessTrackerSecurity(),
      this.assessPrivacySecurity(),
    ]);
    
    // Calculate overall threat level
    const overallThreatLevel = this.calculateOverallThreatLevel(
      networkThreats,
      cellularThreats,
      trackerThreats
    );
    
    // Generate recommendations
    const recommendations = this.generateUnifiedRecommendations(
      networkThreats,
      cellularThreats,
      trackerThreats,
      privacyStatus
    );
    
    return {
      overallThreatLevel,
      lastAssessmentTime: Date.now(),
      threatSummary: {
        networkThreats: networkThreats.threatsDetected.length,
        imsiThreats: cellularThreats.threatsDetected.length,
        trackerThreats: trackerThreats.stalkerDetections.length,
        totalThreats:
          networkThreats.threatsDetected.length +
          cellularThreats.threatsDetected.length +
          trackerThreats.stalkerDetections.length,
      },
      recommendations,
      details: {
        network: networkThreats,
        cellular: cellularThreats,
        trackers: trackerThreats,
        privacy: privacyStatus,
      },
    };
  }
  
  /**
   * Assess network security
   */
  private async assessNetworkSecurity(): Promise<NetworkThreatDetails> {
    // Simulate network scan
    const devices = simulateNetworkScan('192.168.1.0/24');
    this.networkDevices = devices;
    
    // Detect threats
    const mitmThreats = detectMitmAttacks(devices);
    const arpThreats = detectArpSpoofing(devices);
    const allThreats = [...mitmThreats, ...arpThreats];
    
    // Assess overall security
    const assessment = assessNetworkSecurity(devices);
    
    // Extract critical services
    const criticalServices = devices
      .filter(d => d.vulnerabilities.length > 0)
      .flatMap(d => d.services);
    
    return {
      devicesScanned: devices.length,
      threatsDetected: allThreats,
      criticalServices: [...new Set(criticalServices)],
      riskLevel: assessment.overallRisk,
    };
  }
  
  /**
   * Assess cellular security
   */
  private async assessCellularSecurity(): Promise<CellularThreatDetails> {
    if (this.cellularSignals.length === 0) {
      return {
        currentSignal: null,
        threatsDetected: [],
        threatLevel: 'safe',
        recommendations: [],
      };
    }
    
    const currentSignal = this.cellularSignals[this.cellularSignals.length - 1];
    const threats = detectImsiCatcher(
      currentSignal,
      this.cellularSignals.slice(-10), // Last 10 signals
      this.userLocations[this.userLocations.length - 1]
    );
    
    const threatLevel = calculateImsiThreatLevel(threats);
    const recommendations = generateImsiRecommendations(threats);
    
    return {
      currentSignal,
      threatsDetected: threats,
      threatLevel,
      recommendations,
    };
  }
  
  /**
   * Assess tracker security
   */
  private async assessTrackerSecurity(): Promise<TrackerThreatDetails> {
    const suspiciousTrackers: TrackerProfile[] = [];
    const stalkerDetections: StalkerDetection[] = [];
    
    // Assess each tracker
    this.trackers.forEach(tracker => {
      if (!tracker.isIgnored && !tracker.isKnown) {
        const userMovement = this.userMovementPattern || {
          trackerId: '',
          locations: this.userLocations,
          averageDistance: 0,
          maxDistance: 0,
          minDistance: 0,
          correlationWithUserMovement: 0,
          isStationary: false,
          speed: 0,
        };
        
        const assessment = assessTrackerThreat(
          tracker,
          userMovement,
          this.userLocations
        );
        
        if (assessment.overallSeverity !== 'safe') {
          suspiciousTrackers.push(tracker);
          stalkerDetections.push(...assessment.detections);
        }
      }
    });
    
    // Determine overall risk level
    let riskLevel: 'low' | 'medium' | 'high' | 'critical' = 'low';
    if (stalkerDetections.some(d => d.severity === 'critical')) {
      riskLevel = 'critical';
    } else if (stalkerDetections.some(d => d.severity === 'high')) {
      riskLevel = 'high';
    } else if (stalkerDetections.length > 0) {
      riskLevel = 'medium';
    }
    
    return {
      trackersDetected: this.trackers.length,
      suspiciousTrackers,
      stalkerDetections,
      riskLevel,
    };
  }
  
  /**
   * Assess privacy security
   */
  private async assessPrivacySecurity(): Promise<PrivacyDetails> {
    const stats = this.anonymizer?.getStats() || {
      totalFramesProcessed: 0,
      totalFacesDetected: 0,
      totalFacesAnonymized: 0,
      averageProcessingTimeMs: 0,
      detectionAccuracy: 0,
    };
    
    // Calculate privacy score
    const anonymizationRate =
      stats.totalFacesDetected > 0
        ? (stats.totalFacesAnonymized / stats.totalFacesDetected) * 100
        : 100;
    
    const privacyScore = Math.min(100, anonymizationRate);
    
    let exposureRisk: 'low' | 'medium' | 'high' = 'low';
    if (privacyScore < 50) {
      exposureRisk = 'high';
    } else if (privacyScore < 80) {
      exposureRisk = 'medium';
    }
    
    return {
      facesAnonymized: stats.totalFacesAnonymized,
      privacyScore,
      exposureRisk,
    };
  }
  
  /**
   * Calculate overall threat level
   */
  private calculateOverallThreatLevel(
    network: NetworkThreatDetails,
    cellular: CellularThreatDetails,
    trackers: TrackerThreatDetails
  ): 'safe' | 'low' | 'medium' | 'high' | 'critical' {
    const threatLevels = [network.riskLevel, cellular.threatLevel, trackers.riskLevel];
    
    if (threatLevels.includes('critical')) return 'critical';
    if (threatLevels.includes('high')) return 'high';
    if (threatLevels.includes('medium')) return 'medium';
    if (threatLevels.includes('low')) return 'low';
    
    return 'safe';
  }
  
  /**
   * Generate unified recommendations
   */
  private generateUnifiedRecommendations(
    network: NetworkThreatDetails,
    cellular: CellularThreatDetails,
    trackers: TrackerThreatDetails,
    privacy: PrivacyDetails
  ): string[] {
    const recommendations: Set<string> = new Set();
    
    // Network recommendations
    if (network.riskLevel !== 'low') {
      recommendations.add('Review and secure network devices');
      recommendations.add('Enable firewall and network segmentation');
    }
    
    // Cellular recommendations
    if (cellular.threatLevel !== 'safe') {
      recommendations.add('Enable VPN to encrypt cellular traffic');
      recommendations.add('Disable 2G networks if possible');
    }
    
    // Tracker recommendations
    if (trackers.riskLevel !== 'low') {
      recommendations.add('Investigate unknown Bluetooth devices');
      if (trackers.riskLevel === 'critical') {
        recommendations.add('URGENT: Contact local authorities');
      }
    }
    
    // Privacy recommendations
    if (privacy.exposureRisk !== 'low') {
      recommendations.add('Enable facial anonymization in camera');
      recommendations.add('Review privacy settings');
    }
    
    // General recommendations
    recommendations.add('Keep device software up to date');
    recommendations.add('Use strong, unique passwords');
    recommendations.add('Enable two-factor authentication');
    
    return Array.from(recommendations);
  }
  
  /**
   * Update cellular signal data
   */
  updateCellularSignal(signal: CellularSignal): void {
    this.cellularSignals.push(signal);
    // Keep last 100 signals
    if (this.cellularSignals.length > 100) {
      this.cellularSignals.shift();
    }
  }
  
  /**
   * Update tracker data
   */
  updateTracker(tracker: TrackerProfile): void {
    const existingIndex = this.trackers.findIndex(t => t.id === tracker.id);
    if (existingIndex >= 0) {
      this.trackers[existingIndex] = tracker;
    } else {
      this.trackers.push(tracker);
    }
  }
  
  /**
   * Update user location
   */
  updateUserLocation(location: GeoLocation): void {
    this.userLocations.push(location);
    // Keep last 1000 locations
    if (this.userLocations.length > 1000) {
      this.userLocations.shift();
    }
  }
  
  /**
   * Update user movement pattern
   */
  updateMovementPattern(pattern: MovementPattern): void {
    this.userMovementPattern = pattern;
  }
  
  /**
   * Get current anonymizer stats
   */
  getAnonymizerStats() {
    return this.anonymizer?.getStats();
  }
  
  /**
   * Reset all data
   */
  reset(): void {
    this.networkDevices = [];
    this.cellularSignals = [];
    this.trackers = [];
    this.userLocations = [];
    this.userMovementPattern = null;
    this.anonymizer?.resetStats();
  }
}
