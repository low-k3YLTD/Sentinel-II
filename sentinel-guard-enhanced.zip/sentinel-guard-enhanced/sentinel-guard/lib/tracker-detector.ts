/**
 * Bluetooth Tracker & Stalker Detection Module
 * Detects AirTags, Tiles, and other BLE trackers
 * Implements stalker car detection using movement patterns
 */

export interface BleAdvertisement {
  id: string;
  macAddress: string;
  name?: string;
  rssi: number; // Signal strength in dBm
  txPower?: number; // Transmit power
  manufacturerData?: Buffer;
  serviceUuids?: string[];
  timestamp: number;
}

export interface TrackerProfile {
  id: string;
  name: string;
  type: 'airtag' | 'tile' | 'chipolo' | 'smarttag' | 'unknown';
  macAddress: string;
  firstSeen: number;
  lastSeen: number;
  sightingCount: number;
  locations: GeoLocation[];
  riskScore: number; // 0-100
  isKnown: boolean;
  isIgnored: boolean;
}

export interface GeoLocation {
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: number;
}

export interface StalkerDetection {
  id: string;
  trackerId: string;
  type: 'persistent_follower' | 'car_based_tracking' | 'location_correlation' | 'movement_pattern';
  severity: 'low' | 'medium' | 'high' | 'critical';
  confidence: number; // 0-100
  description: string;
  evidence: string[];
  timestamp: number;
  recommendations: string[];
}

export interface MovementPattern {
  trackerId: string;
  locations: GeoLocation[];
  averageDistance: number; // meters
  maxDistance: number; // meters
  minDistance: number; // meters
  correlationWithUserMovement: number; // 0-100
  isStationary: boolean;
  speed: number; // m/s
}

// Known tracker service UUIDs
const KNOWN_TRACKERS = {
  airtag: {
    serviceUuid: '0xFD6F', // Apple Find My
    manufacturerId: 0x004C, // Apple
    patterns: ['Apple', 'AirTag'],
  },
  tile: {
    serviceUuid: '0xFEED',
    manufacturerId: 0x013D,
    patterns: ['Tile', 'TILE'],
  },
  chipolo: {
    serviceUuid: '0xFFF0',
    manufacturerId: 0x0105,
    patterns: ['Chipolo'],
  },
  smarttag: {
    serviceUuid: '0x110C',
    manufacturerId: 0x0075, // Samsung
    patterns: ['SmartTag'],
  },
};

/**
 * Identify tracker type from BLE advertisement
 */
export function identifyTrackerType(
  advertisement: BleAdvertisement
): 'airtag' | 'tile' | 'chipolo' | 'smarttag' | 'unknown' {
  const name = advertisement.name?.toLowerCase() || '';
  
  // Check by service UUID
  if (advertisement.serviceUuids?.includes(KNOWN_TRACKERS.airtag.serviceUuid)) {
    return 'airtag';
  }
  if (advertisement.serviceUuids?.includes(KNOWN_TRACKERS.tile.serviceUuid)) {
    return 'tile';
  }
  if (advertisement.serviceUuids?.includes(KNOWN_TRACKERS.chipolo.serviceUuid)) {
    return 'chipolo';
  }
  if (advertisement.serviceUuids?.includes(KNOWN_TRACKERS.smarttag.serviceUuid)) {
    return 'smarttag';
  }
  
  // Check by name pattern
  for (const [type, config] of Object.entries(KNOWN_TRACKERS)) {
    if (config.patterns.some(pattern => name.includes(pattern.toLowerCase()))) {
      return type as 'airtag' | 'tile' | 'chipolo' | 'smarttag';
    }
  }
  
  return 'unknown';
}

/**
 * Calculate distance from RSSI (signal strength)
 * Uses free-space path loss model
 */
export function calculateDistance(rssi: number, txPower: number = -59): number {
  // Formula: distance = 10^((txPower - rssi) / (10 * N))
  // N = path loss exponent (typically 2 for free space)
  const N = 2;
  const distance = Math.pow(10, (txPower - rssi) / (10 * N));
  return distance;
}

/**
 * Detect persistent follower pattern
 * A device that stays within close proximity over extended time
 */
export function detectPersistentFollower(
  tracker: TrackerProfile,
  timeWindowMinutes: number = 30
): StalkerDetection | null {
  if (tracker.locations.length < 5) return null;
  
  const recentLocations = tracker.locations.filter(
    loc => Date.now() - loc.timestamp < timeWindowMinutes * 60 * 1000
  );
  
  if (recentLocations.length < 3) return null;
  
  // Calculate average distance between consecutive locations
  let totalDistance = 0;
  for (let i = 1; i < recentLocations.length; i++) {
    const distance = calculateGeoDistance(
      recentLocations[i - 1],
      recentLocations[i]
    );
    totalDistance += distance;
  }
  
  const averageDistance = totalDistance / (recentLocations.length - 1);
  
  // If device stays within 100 meters consistently, it's suspicious
  if (averageDistance < 100) {
    const confidence = Math.min(
      100,
      50 + (tracker.sightingCount * 5) + ((30 - timeWindowMinutes) * 2)
    );
    
    return {
      id: `stalker_${tracker.id}_${Date.now()}`,
      trackerId: tracker.id,
      type: 'persistent_follower',
      severity: confidence > 80 ? 'critical' : 'high',
      confidence,
      description: `Unknown ${tracker.type} device has maintained proximity (avg ${averageDistance.toFixed(0)}m) for ${timeWindowMinutes} minutes.`,
      evidence: [
        `Sighting count: ${tracker.sightingCount}`,
        `Average distance: ${averageDistance.toFixed(0)}m`,
        `Time window: ${timeWindowMinutes} minutes`,
        `Locations tracked: ${recentLocations.length}`,
      ],
      timestamp: Date.now(),
      recommendations: [
        'Move to a public place with witnesses',
        'Call local authorities if you feel threatened',
        'Enable airplane mode to disconnect from Bluetooth',
        'Check your belongings for physical trackers',
      ],
    };
  }
  
  return null;
}

/**
 * Detect car-based tracking pattern
 * A device that moves with the user at vehicle speeds
 */
export function detectCarBasedTracking(
  tracker: TrackerProfile,
  userMovementPattern: MovementPattern
): StalkerDetection | null {
  if (tracker.locations.length < 10) return null;
  
  // Calculate tracker movement pattern
  const trackerPattern = analyzeMovementPattern(tracker.locations);
  
  // Check if tracker moves with user at vehicle speeds (>10 m/s)
  if (trackerPattern.speed > 10 && trackerPattern.speed < 40) {
    // Typical car speeds: 10-40 m/s (36-144 km/h)
    
    // Check correlation with user movement
    const correlation = correlateMovements(trackerPattern, userMovementPattern);
    
    if (correlation > 70) {
      return {
        id: `stalker_car_${tracker.id}_${Date.now()}`,
        trackerId: tracker.id,
        type: 'car_based_tracking',
        severity: 'critical',
        confidence: correlation,
        description: `${tracker.type} device is moving with you at vehicle speeds (${trackerPattern.speed.toFixed(1)} m/s) with ${correlation.toFixed(0)}% movement correlation.`,
        evidence: [
          `Movement speed: ${trackerPattern.speed.toFixed(1)} m/s (vehicle speed)`,
          `Movement correlation: ${correlation.toFixed(0)}%`,
          `Distance maintained: ${trackerPattern.averageDistance.toFixed(0)}m`,
          `Locations: ${tracker.locations.length}`,
        ],
        timestamp: Date.now(),
        recommendations: [
          'URGENT: Drive to nearest police station',
          'Do not go home - go to a public place',
          'Call emergency services immediately',
          'Note the vehicle details if possible',
          'Save this evidence for law enforcement',
        ],
      };
    }
  }
  
  return null;
}

/**
 * Detect location correlation with known dangerous areas
 */
export function detectLocationCorrelation(
  tracker: TrackerProfile,
  userLocations: GeoLocation[]
): StalkerDetection | null {
  if (tracker.locations.length < 3 || userLocations.length < 3) return null;
  
  // Count overlapping locations
  let overlappingLocations = 0;
  const proximityThreshold = 100; // 100 meters
  
  tracker.locations.forEach(trackerLoc => {
    userLocations.forEach(userLoc => {
      const distance = calculateGeoDistance(trackerLoc, userLoc);
      if (distance < proximityThreshold) {
        overlappingLocations++;
      }
    });
  });
  
  const correlationPercentage = (overlappingLocations / tracker.locations.length) * 100;
  
  if (correlationPercentage > 60) {
    return {
      id: `stalker_location_${tracker.id}_${Date.now()}`,
      trackerId: tracker.id,
      type: 'location_correlation',
      severity: 'high',
      confidence: Math.min(100, correlationPercentage),
      description: `${tracker.type} device has been detected at ${overlappingLocations} of your recent locations (${correlationPercentage.toFixed(0)}% correlation).`,
      evidence: [
        `Overlapping locations: ${overlappingLocations}`,
        `Correlation: ${correlationPercentage.toFixed(0)}%`,
        `Proximity threshold: ${proximityThreshold}m`,
      ],
      timestamp: Date.now(),
      recommendations: [
        'Review your recent locations and identify patterns',
        'Check for physical trackers in your belongings',
        'Vary your daily routine and routes',
        'Consider reporting to local authorities',
      ],
    };
  }
  
  return null;
}

/**
 * Analyze movement pattern of a tracker
 */
function analyzeMovementPattern(locations: GeoLocation[]): MovementPattern {
  if (locations.length < 2) {
    return {
      trackerId: '',
      locations,
      averageDistance: 0,
      maxDistance: 0,
      minDistance: 0,
      correlationWithUserMovement: 0,
      isStationary: true,
      speed: 0,
    };
  }
  
  let totalDistance = 0;
  let maxDistance = 0;
  let minDistance = Infinity;
  let totalTime = 0;
  
  for (let i = 1; i < locations.length; i++) {
    const distance = calculateGeoDistance(locations[i - 1], locations[i]);
    const time = (locations[i].timestamp - locations[i - 1].timestamp) / 1000; // seconds
    
    totalDistance += distance;
    maxDistance = Math.max(maxDistance, distance);
    minDistance = Math.min(minDistance, distance);
    totalTime += time;
  }
  
  const averageDistance = totalDistance / (locations.length - 1);
  const speed = totalTime > 0 ? totalDistance / totalTime : 0;
  const isStationary = averageDistance < 50; // Less than 50m movement
  
  return {
    trackerId: '',
    locations,
    averageDistance,
    maxDistance,
    minDistance: minDistance === Infinity ? 0 : minDistance,
    correlationWithUserMovement: 0,
    isStationary,
    speed,
  };
}

/**
 * Calculate correlation between two movement patterns
 */
function correlateMovements(
  pattern1: MovementPattern,
  pattern2: MovementPattern
): number {
  // Simplified correlation: check if patterns overlap in time and space
  let correlatedPoints = 0;
  const proximityThreshold = 200; // 200 meters
  
  pattern1.locations.forEach(loc1 => {
    pattern2.locations.forEach(loc2 => {
      const timeDiff = Math.abs(loc1.timestamp - loc2.timestamp);
      const distance = calculateGeoDistance(loc1, loc2);
      
      // If locations are within 5 minutes and 200 meters, they correlate
      if (timeDiff < 5 * 60 * 1000 && distance < proximityThreshold) {
        correlatedPoints++;
      }
    });
  });
  
  return (correlatedPoints / Math.max(pattern1.locations.length, pattern2.locations.length)) * 100;
}

/**
 * Calculate distance between two geographic locations (Haversine formula)
 */
function calculateGeoDistance(loc1: GeoLocation, loc2: GeoLocation): number {
  const R = 6371000; // Earth's radius in meters
  const dLat = toRad(loc2.latitude - loc1.latitude);
  const dLng = toRad(loc2.longitude - loc1.longitude);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(loc1.latitude)) *
      Math.cos(toRad(loc2.latitude)) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function toRad(degrees: number): number {
  return (degrees * Math.PI) / 180;
}

/**
 * Calculate overall risk score for a tracker
 */
export function calculateTrackerRiskScore(
  tracker: TrackerProfile,
  detections: StalkerDetection[]
): number {
  let score = 0;
  
  // Base score from sighting count
  score += Math.min(30, tracker.sightingCount * 2);
  
  // Add points for each detection
  detections.forEach(detection => {
    switch (detection.severity) {
      case 'critical':
        score += 40;
        break;
      case 'high':
        score += 25;
        break;
      case 'medium':
        score += 15;
        break;
      case 'low':
        score += 5;
        break;
    }
  });
  
  // Boost if it's a known tracker type
  if (tracker.type !== 'unknown') {
    score += 10;
  }
  
  return Math.min(100, score);
}

/**
 * Generate comprehensive tracker threat assessment
 */
export function assessTrackerThreat(
  tracker: TrackerProfile,
  userMovementPattern: MovementPattern,
  userLocations: GeoLocation[]
): {
  detections: StalkerDetection[];
  riskScore: number;
  overallSeverity: 'safe' | 'low' | 'medium' | 'high' | 'critical';
} {
  const detections: StalkerDetection[] = [];
  
  // Run all detection heuristics
  const persistent = detectPersistentFollower(tracker);
  if (persistent) detections.push(persistent);
  
  const carTracking = detectCarBasedTracking(tracker, userMovementPattern);
  if (carTracking) detections.push(carTracking);
  
  const locationCorr = detectLocationCorrelation(tracker, userLocations);
  if (locationCorr) detections.push(locationCorr);
  
  const riskScore = calculateTrackerRiskScore(tracker, detections);
  
  let overallSeverity: 'safe' | 'low' | 'medium' | 'high' | 'critical' = 'safe';
  if (detections.some(d => d.severity === 'critical')) {
    overallSeverity = 'critical';
  } else if (detections.some(d => d.severity === 'high')) {
    overallSeverity = 'high';
  } else if (detections.length > 0) {
    overallSeverity = 'medium';
  } else if (riskScore > 30) {
    overallSeverity = 'low';
  }
  
  return {
    detections,
    riskScore,
    overallSeverity,
  };
}
