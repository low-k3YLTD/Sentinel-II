/**
 * IMSI Catcher Detection Module - Advanced Cellular Threat Detection
 * Implements Stingray/IMSI catcher detection using signal heuristics
 */

export interface CellularSignal {
  mcc: string; // Mobile Country Code
  mnc: string; // Mobile Network Code
  lac: string; // Location Area Code
  cellId: string; // Cell ID
  rssi: number; // Signal strength in dBm
  timingAdvance: number; // Distance indicator (0-63)
  networkType: '2G' | '3G' | '4G' | '5G';
  timestamp: number;
}

export interface ImsiThreatIndicator {
  id: string;
  type: 'downgrade' | 'rapid_handover' | 'timing_anomaly' | 'signal_spike' | 'encryption_disabled' | 'frequency_anomaly';
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  confidence: number; // 0-100
  details: Record<string, any>;
  timestamp: number;
}

export interface CellTowerProfile {
  id: string;
  mcc: string;
  mnc: string;
  cellId: string;
  location?: { latitude: number; longitude: number };
  isLegitimate: boolean;
  firstSeen: number;
  lastSeen: number;
  sightingCount: number;
  averageSignal: number;
  anomalyScore: number; // 0-100
}

// Known legitimate carrier MCC/MNC combinations
const LEGITIMATE_CARRIERS: Record<string, string> = {
  '310010': 'Verizon (USA)',
  '310410': 'AT&T (USA)',
  '310260': 'T-Mobile (USA)',
  '310660': 'MetroPCS (USA)',
  '310120': 'Sprint (USA)',
  '310200': 'Sprint (USA)',
  '311480': 'Cricket (USA)',
  '310380': 'Boost Mobile (USA)',
  '310490': 'Virgin Mobile (USA)',
  '310680': 'Tracfone (USA)',
  '310800': 'Clearwire (USA)',
  '310900': 'Globalstar (USA)',
  '311110': 'Verizon (USA)',
  '311270': 'Verizon (USA)',
  '311271': 'Verizon (USA)',
  '311272': 'Verizon (USA)',
  '311273': 'Verizon (USA)',
  '311274': 'Verizon (USA)',
  '311275': 'Verizon (USA)',
  '311276': 'Verizon (USA)',
  '311277': 'Verizon (USA)',
  '311278': 'Verizon (USA)',
  '311279': 'Verizon (USA)',
  '311280': 'Verizon (USA)',
  '311281': 'Verizon (USA)',
  '311282': 'Verizon (USA)',
  '311283': 'Verizon (USA)',
  '311284': 'Verizon (USA)',
  '311285': 'Verizon (USA)',
  '311286': 'Verizon (USA)',
  '311287': 'Verizon (USA)',
  '311288': 'Verizon (USA)',
  '311289': 'Verizon (USA)',
  '311390': 'Verizon (USA)',
  '311480': 'Cricket (USA)',
  '311481': 'Cricket (USA)',
  '311482': 'Cricket (USA)',
  '311483': 'Cricket (USA)',
  '311484': 'Cricket (USA)',
  '311485': 'Cricket (USA)',
  '311486': 'Cricket (USA)',
  '311487': 'Cricket (USA)',
  '311488': 'Cricket (USA)',
  '311489': 'Cricket (USA)',
};

/**
 * Detect 2G downgrade attacks (forcing device to use less secure 2G)
 */
export function detect2gDowngrade(
  currentSignal: CellularSignal,
  previousSignal: CellularSignal | null
): ImsiThreatIndicator | null {
  if (!previousSignal) return null;
  
  // Check if network type downgraded to 2G
  if (previousSignal.networkType !== '2G' && currentSignal.networkType === '2G') {
    return {
      id: `threat_2g_downgrade_${Date.now()}`,
      type: 'downgrade',
      severity: 'critical',
      title: '2G Network Downgrade Detected',
      description: `Device was forced to downgrade from ${previousSignal.networkType} to 2G. This is a classic IMSI catcher attack vector.`,
      confidence: 95,
      details: {
        previousNetworkType: previousSignal.networkType,
        currentNetworkType: currentSignal.networkType,
        timeSinceDowngrade: Date.now() - previousSignal.timestamp,
      },
      timestamp: Date.now(),
    };
  }
  
  return null;
}

/**
 * Detect rapid cell tower handovers (suspicious pattern)
 */
export function detectRapidHandover(
  signals: CellularSignal[],
  timeWindowMs: number = 60000 // 1 minute
): ImsiThreatIndicator | null {
  if (signals.length < 3) return null;
  
  const recentSignals = signals.filter(s => Date.now() - s.timestamp < timeWindowMs);
  
  // Check for rapid cell ID changes
  const uniqueCellIds = new Set(recentSignals.map(s => s.cellId));
  
  if (uniqueCellIds.size >= 3) {
    return {
      id: `threat_rapid_handover_${Date.now()}`,
      type: 'rapid_handover',
      severity: 'high',
      title: 'Rapid Cell Tower Handovers Detected',
      description: `Device connected to ${uniqueCellIds.size} different cell towers in ${timeWindowMs / 1000} seconds. This may indicate a MITM attack.`,
      confidence: 80,
      details: {
        handoverCount: uniqueCellIds.size,
        timeWindow: timeWindowMs,
        cellIds: Array.from(uniqueCellIds),
      },
      timestamp: Date.now(),
    };
  }
  
  return null;
}

/**
 * Detect timing advance anomalies (distance inconsistencies)
 */
export function detectTimingAnomaly(
  signal: CellularSignal,
  userLocation?: { latitude: number; longitude: number }
): ImsiThreatIndicator | null {
  // Timing Advance ranges from 0-63, each unit ≈ 550 meters
  // Maximum distance is ~35km (63 * 550m)
  
  const timingAdvanceDistance = signal.timingAdvance * 550; // meters
  
  // If timing advance is at maximum and signal is very strong, suspicious
  if (signal.timingAdvance >= 60 && signal.rssi > -70) {
    return {
      id: `threat_timing_anomaly_${Date.now()}`,
      type: 'timing_anomaly',
      severity: 'medium',
      title: 'Timing Advance Anomaly Detected',
      description: `Cell tower is at maximum distance (${timingAdvanceDistance}m) but has unusually strong signal. This may indicate a nearby rogue tower.`,
      confidence: 70,
      details: {
        timingAdvance: signal.timingAdvance,
        calculatedDistance: timingAdvanceDistance,
        signalStrength: signal.rssi,
      },
      timestamp: Date.now(),
    };
  }
  
  return null;
}

/**
 * Detect signal strength anomalies
 */
export function detectSignalAnomaly(
  currentSignal: CellularSignal,
  previousSignals: CellularSignal[]
): ImsiThreatIndicator | null {
  if (previousSignals.length === 0) return null;
  
  // Calculate average signal strength
  const avgSignal = previousSignals.reduce((sum, s) => sum + s.rssi, 0) / previousSignals.length;
  const signalChange = currentSignal.rssi - avgSignal;
  
  // Sudden spike in signal strength (>10dB increase) is suspicious
  if (signalChange > 10) {
    return {
      id: `threat_signal_spike_${Date.now()}`,
      type: 'signal_spike',
      severity: 'medium',
      title: 'Abnormal Signal Strength Spike',
      description: `Signal strength suddenly increased by ${signalChange.toFixed(1)}dB. A nearby rogue tower may be active.`,
      confidence: 65,
      details: {
        previousAverage: avgSignal.toFixed(1),
        currentSignal: currentSignal.rssi,
        change: signalChange.toFixed(1),
      },
      timestamp: Date.now(),
    };
  }
  
  return null;
}

/**
 * Validate carrier MCC/MNC combination
 */
export function validateCarrier(mcc: string, mnc: string): ImsiThreatIndicator | null {
  const mccMnc = `${mcc}${mnc}`;
  
  // Check if this is a known legitimate carrier
  if (!LEGITIMATE_CARRIERS[mccMnc]) {
    return {
      id: `threat_invalid_carrier_${Date.now()}`,
      type: 'frequency_anomaly',
      severity: 'high',
      title: 'Unknown Carrier Detected',
      description: `Device is connected to unknown MCC/MNC combination (${mcc}/${mnc}). This may be a fake cell tower.`,
      confidence: 85,
      details: {
        mcc,
        mnc,
        mccMnc,
      },
      timestamp: Date.now(),
    };
  }
  
  return null;
}

/**
 * Comprehensive IMSI catcher detection
 */
export function detectImsiCatcher(
  currentSignal: CellularSignal,
  signalHistory: CellularSignal[],
  userLocation?: { latitude: number; longitude: number }
): ImsiThreatIndicator[] {
  const threats: ImsiThreatIndicator[] = [];
  
  // Run all detection heuristics
  const downgrade = detect2gDowngrade(currentSignal, signalHistory[signalHistory.length - 1] || null);
  if (downgrade) threats.push(downgrade);
  
  const handover = detectRapidHandover(signalHistory);
  if (handover) threats.push(handover);
  
  const timing = detectTimingAnomaly(currentSignal, userLocation);
  if (timing) threats.push(timing);
  
  const signal = detectSignalAnomaly(currentSignal, signalHistory);
  if (signal) threats.push(signal);
  
  const carrier = validateCarrier(currentSignal.mcc, currentSignal.mnc);
  if (carrier) threats.push(carrier);
  
  return threats;
}

/**
 * Calculate overall IMSI threat level
 */
export function calculateImsiThreatLevel(threats: ImsiThreatIndicator[]): 'safe' | 'low' | 'medium' | 'high' | 'critical' {
  if (threats.length === 0) return 'safe';
  
  const criticalCount = threats.filter(t => t.severity === 'critical').length;
  const highCount = threats.filter(t => t.severity === 'high').length;
  const mediumCount = threats.filter(t => t.severity === 'medium').length;
  
  if (criticalCount > 0) return 'critical';
  if (highCount >= 2) return 'high';
  if (highCount > 0 || mediumCount >= 2) return 'medium';
  if (mediumCount > 0) return 'low';
  
  return 'safe';
}

/**
 * Generate recommendations based on detected threats
 */
export function generateImsiRecommendations(threats: ImsiThreatIndicator[]): string[] {
  const recommendations: Set<string> = new Set();
  
  threats.forEach(threat => {
    switch (threat.type) {
      case 'downgrade':
        recommendations.add('Disable 2G networks in your phone settings immediately');
        recommendations.add('Contact your carrier to verify network legitimacy');
        break;
      case 'rapid_handover':
        recommendations.add('Move to a different location and monitor for continued handovers');
        recommendations.add('Enable airplane mode and re-enable cellular to force reconnection');
        break;
      case 'timing_anomaly':
        recommendations.add('Verify cell tower location with your carrier');
        recommendations.add('Use GPS to cross-reference tower location');
        break;
      case 'signal_spike':
        recommendations.add('Check for nearby cell towers using OpenCellID');
        recommendations.add('Move away from the area and monitor signal');
        break;
      case 'frequency_anomaly':
        recommendations.add('Contact your carrier immediately');
        recommendations.add('Consider switching to a different carrier temporarily');
        break;
    }
  });
  
  // Add general recommendations
  recommendations.add('Enable VPN to encrypt cellular traffic');
  recommendations.add('Use end-to-end encrypted messaging apps');
  recommendations.add('Disable auto-connect to cellular networks');
  
  return Array.from(recommendations);
}
