/**
 * Network Scanner Module - Advanced Network Threat Detection
 * Implements Fing-like network scanning capabilities
 */

export interface NetworkDevice {
  id: string;
  ipAddress: string;
  macAddress: string;
  hostname: string | null;
  deviceType: string;
  manufacturer: string;
  openPorts: number[];
  services: string[];
  vulnerabilities: string[];
  lastSeen: number;
  firstSeen: number;
  isLocal: boolean;
  riskScore: number; // 0-100
}

export interface NetworkThreat {
  id: string;
  type: 'open_port' | 'weak_service' | 'outdated_version' | 'mitm_detected' | 'arp_spoofing';
  severity: 'low' | 'medium' | 'high' | 'critical';
  device: NetworkDevice;
  description: string;
  recommendation: string;
  timestamp: number;
}

export interface ScanResult {
  id: string;
  startTime: number;
  endTime?: number;
  devicesFound: NetworkDevice[];
  threatsDetected: NetworkThreat[];
  networkInfo: {
    ssid: string;
    bssid: string;
    ipRange: string;
    gatewayIp: string;
    dnsServers: string[];
  };
  status: 'scanning' | 'completed' | 'error';
}

// MAC OUI Database (Manufacturer lookup)
const MAC_OUI_DATABASE: Record<string, string> = {
  '00:1A:2B': 'Apple Inc.',
  '00:11:22': 'Cisco Systems',
  '08:00:27': 'PCS Systemtechnik',
  '00:0C:29': 'VMware Inc.',
  '52:54:00': 'QEMU',
  'AC:DE:48': 'Google Inc.',
  'B8:27:EB': 'Raspberry Pi Foundation',
  '00:50:F2': 'Microsoft Corporation',
  'D4:6E:0E': 'Apple Inc.',
  'E4:F4:C6': 'Apple Inc.',
};

// Common service ports and their vulnerabilities
const COMMON_PORTS: Record<number, { service: string; vulnerabilities: string[] }> = {
  21: { service: 'FTP', vulnerabilities: ['Unencrypted credentials', 'Outdated protocol'] },
  22: { service: 'SSH', vulnerabilities: ['Brute force attacks', 'Key exchange vulnerabilities'] },
  23: { service: 'Telnet', vulnerabilities: ['Unencrypted communication', 'Deprecated protocol'] },
  25: { service: 'SMTP', vulnerabilities: ['Email spoofing', 'Relay abuse'] },
  53: { service: 'DNS', vulnerabilities: ['DNS poisoning', 'Cache poisoning'] },
  80: { service: 'HTTP', vulnerabilities: ['No encryption', 'Man-in-the-middle attacks'] },
  139: { service: 'NetBIOS', vulnerabilities: ['Information disclosure', 'Lateral movement'] },
  445: { service: 'SMB', vulnerabilities: ['Ransomware vector', 'Lateral movement'] },
  3306: { service: 'MySQL', vulnerabilities: ['Unencrypted data', 'Default credentials'] },
  3389: { service: 'RDP', vulnerabilities: ['Brute force attacks', 'Credential theft'] },
  5432: { service: 'PostgreSQL', vulnerabilities: ['Unencrypted data', 'Default credentials'] },
  5900: { service: 'VNC', vulnerabilities: ['Weak encryption', 'Brute force attacks'] },
  8080: { service: 'HTTP-Proxy', vulnerabilities: ['Proxy abuse', 'Man-in-the-middle'] },
  27017: { service: 'MongoDB', vulnerabilities: ['No authentication', 'Data exposure'] },
};

/**
 * Simulates network device discovery (ARP scan)
 * In production, would use actual network APIs
 */
export function simulateNetworkScan(
  ipRange: string = '192.168.1.0/24',
  onProgress?: (progress: number) => void
): NetworkDevice[] {
  const devices: NetworkDevice[] = [];
  const baseIp = ipRange.split('/')[0].split('.').slice(0, 3).join('.');
  
  // Simulate scanning 254 addresses (typical /24 subnet)
  for (let i = 1; i <= 254; i++) {
    const progress = (i / 254) * 100;
    if (onProgress) onProgress(progress);
    
    // 30% chance of finding a device
    if (Math.random() < 0.3) {
      const device = generateMockNetworkDevice(
        `${baseIp}.${i}`,
        Math.random() < 0.1 // 10% chance of vulnerability
      );
      devices.push(device);
    }
  }
  
  return devices;
}

/**
 * Generate a mock network device with realistic data
 */
function generateMockNetworkDevice(ipAddress: string, hasVulnerability: boolean): NetworkDevice {
  const deviceTypes = ['Router', 'Printer', 'Smart TV', 'Laptop', 'Phone', 'IoT Device', 'Server'];
  const deviceType = deviceTypes[Math.floor(Math.random() * deviceTypes.length)];
  const macAddress = generateMacAddress();
  const manufacturer = lookupManufacturer(macAddress);
  
  // Generate open ports (typically 1-5 on a device)
  const openPorts: number[] = [];
  const portCount = Math.floor(Math.random() * 4) + 1;
  const availablePorts = Object.keys(COMMON_PORTS).map(Number);
  
  for (let i = 0; i < portCount; i++) {
    const port = availablePorts[Math.floor(Math.random() * availablePorts.length)];
    if (!openPorts.includes(port)) {
      openPorts.push(port);
    }
  }
  
  // Get services and vulnerabilities for open ports
  const services = openPorts.map(port => COMMON_PORTS[port]?.service || 'Unknown');
  const vulnerabilities = hasVulnerability
    ? openPorts.flatMap(port => COMMON_PORTS[port]?.vulnerabilities || [])
    : [];
  
  // Calculate risk score based on vulnerabilities and open ports
  const riskScore = Math.min(
    100,
    (openPorts.length * 10) + (vulnerabilities.length * 15) + (hasVulnerability ? 20 : 0)
  );
  
  return {
    id: `device_${macAddress}`,
    ipAddress,
    macAddress,
    hostname: generateHostname(deviceType),
    deviceType,
    manufacturer,
    openPorts,
    services,
    vulnerabilities,
    lastSeen: Date.now(),
    firstSeen: Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000, // Random time in last 30 days
    isLocal: true,
    riskScore,
  };
}

/**
 * Generate a random MAC address
 */
function generateMacAddress(): string {
  return Array.from({ length: 6 }, () =>
    Math.floor(Math.random() * 256)
      .toString(16)
      .padStart(2, '0')
  ).join(':');
}

/**
 * Look up manufacturer from MAC OUI
 */
function lookupManufacturer(macAddress: string): string {
  const oui = macAddress.substring(0, 8).toUpperCase();
  return MAC_OUI_DATABASE[oui] || 'Unknown Manufacturer';
}

/**
 * Generate a realistic hostname
 */
function generateHostname(deviceType: string): string {
  const prefixes = ['device', 'host', 'server', 'router', 'printer', 'tv'];
  const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
  const number = Math.floor(Math.random() * 1000);
  return `${prefix}-${number}`;
}

/**
 * Detect potential MITM attacks by analyzing network traffic patterns
 */
export function detectMitmAttacks(devices: NetworkDevice[]): NetworkThreat[] {
  const threats: NetworkThreat[] = [];
  
  devices.forEach(device => {
    // Check for suspicious patterns
    if (device.openPorts.includes(445) && device.openPorts.includes(139)) {
      // SMB and NetBIOS open - potential lateral movement vector
      threats.push({
        id: `threat_${device.id}_smb`,
        type: 'mitm_detected',
        severity: 'high',
        device,
        description: 'Device has both SMB (445) and NetBIOS (139) ports open, enabling lateral movement attacks.',
        recommendation: 'Restrict SMB access to trusted networks only. Consider disabling NetBIOS.',
        timestamp: Date.now(),
      });
    }
    
    if (device.openPorts.includes(80) && !device.openPorts.includes(443)) {
      // HTTP without HTTPS - MITM vulnerability
      threats.push({
        id: `threat_${device.id}_http`,
        type: 'mitm_detected',
        severity: 'medium',
        device,
        description: 'Device serves HTTP traffic without HTTPS encryption, vulnerable to MITM attacks.',
        recommendation: 'Enable HTTPS/TLS encryption for all web services.',
        timestamp: Date.now(),
      });
    }
    
    // Check for weak services
    if (device.openPorts.includes(23)) {
      threats.push({
        id: `threat_${device.id}_telnet`,
        type: 'weak_service',
        severity: 'critical',
        device,
        description: 'Telnet (port 23) is enabled. Telnet transmits credentials in plaintext.',
        recommendation: 'Disable Telnet immediately and use SSH instead.',
        timestamp: Date.now(),
      });
    }
    
    if (device.openPorts.includes(21)) {
      threats.push({
        id: `threat_${device.id}_ftp`,
        type: 'weak_service',
        severity: 'high',
        device,
        description: 'FTP (port 21) is enabled. FTP transmits credentials in plaintext.',
        recommendation: 'Disable FTP and use SFTP or SCP for secure file transfer.',
        timestamp: Date.now(),
      });
    }
  });
  
  return threats;
}

/**
 * Analyze network for ARP spoofing indicators
 */
export function detectArpSpoofing(devices: NetworkDevice[]): NetworkThreat[] {
  const threats: NetworkThreat[] = [];
  
  // In a real implementation, this would analyze ARP tables
  // For now, we simulate detection based on suspicious patterns
  devices.forEach(device => {
    // Simulate ARP spoofing detection (10% chance)
    if (Math.random() < 0.1) {
      threats.push({
        id: `threat_${device.id}_arp`,
        type: 'arp_spoofing',
        severity: 'critical',
        device,
        description: `Potential ARP spoofing detected from ${device.macAddress}. MAC address may be forged.`,
        recommendation: 'Enable ARP inspection on your router. Consider using static ARP entries for critical devices.',
        timestamp: Date.now(),
      });
    }
  });
  
  return threats;
}

/**
 * Comprehensive network security assessment
 */
export function assessNetworkSecurity(devices: NetworkDevice[]): {
  overallRisk: 'low' | 'medium' | 'high' | 'critical';
  threatCount: number;
  recommendations: string[];
} {
  const mitm = detectMitmAttacks(devices);
  const arp = detectArpSpoofing(devices);
  const allThreats = [...mitm, ...arp];
  
  const criticalCount = allThreats.filter(t => t.severity === 'critical').length;
  const highCount = allThreats.filter(t => t.severity === 'high').length;
  
  let overallRisk: 'low' | 'medium' | 'high' | 'critical' = 'low';
  if (criticalCount > 0) overallRisk = 'critical';
  else if (highCount > 2) overallRisk = 'high';
  else if (highCount > 0 || allThreats.length > 5) overallRisk = 'medium';
  
  const recommendations: string[] = [];
  if (criticalCount > 0) {
    recommendations.push('CRITICAL: Disable deprecated services (Telnet, FTP) immediately');
  }
  if (highCount > 0) {
    recommendations.push('Enable HTTPS on all web services');
    recommendations.push('Restrict SMB/NetBIOS access to trusted networks');
  }
  recommendations.push('Enable network segmentation and VLANs');
  recommendations.push('Use strong encryption for all network communications');
  recommendations.push('Regularly update and patch all network devices');
  
  return {
    overallRisk,
    threatCount: allThreats.length,
    recommendations,
  };
}
