// Mock data generator for Sentinel Guard
// Simulates cell tower data, Bluetooth devices, and security alerts

import {
  CellTower,
  ThreatIndicator,
  SecurityStatus,
  BluetoothDevice,
  Alert,
  ThreatLevel,
  NetworkType,
} from '@/types/security';

// Generate random ID
const generateId = () => Math.random().toString(36).substring(2, 15);

// Generate random number in range
const randomInRange = (min: number, max: number) => 
  Math.floor(Math.random() * (max - min + 1)) + min;

// US Mobile Country Code
const MCC = '310';

// Common US Mobile Network Codes
const MNC_LIST = ['260', '410', '120', '150', '170']; // T-Mobile, AT&T, Sprint, etc.

// Generate mock cell tower data
export function generateMockCellTower(isAnomaly: boolean = false): CellTower {
  const networkTypes: NetworkType[] = isAnomaly ? ['2G', '3G'] : ['4G', '5G', '4G', '4G'];
  
  return {
    id: generateId(),
    mcc: MCC,
    mnc: MNC_LIST[randomInRange(0, MNC_LIST.length - 1)],
    lac: isAnomaly ? '0000' : randomInRange(1000, 9999).toString(),
    cellId: randomInRange(10000, 99999).toString(),
    networkType: networkTypes[randomInRange(0, networkTypes.length - 1)],
    signalStrength: isAnomaly ? randomInRange(-110, -90) : randomInRange(-85, -50),
    timestamp: Date.now(),
    isConnected: true,
  };
}

// Generate threat indicators based on cell tower analysis
export function generateThreatIndicators(tower: CellTower): ThreatIndicator[] {
  const indicators: ThreatIndicator[] = [];
  
  // Check for 2G downgrade (suspicious)
  if (tower.networkType === '2G') {
    indicators.push({
      id: generateId(),
      type: 'downgrade',
      severity: 'high',
      title: '2G Network Downgrade Detected',
      description: 'Your connection was forced to 2G, which lacks encryption. This is a common IMSI catcher technique.',
      timestamp: Date.now(),
      details: {
        previousNetwork: '4G',
        currentNetwork: '2G',
      },
    });
  }
  
  // Check for unusual LAC (Location Area Code)
  if (tower.lac === '0000' || tower.lac === 'FFFF') {
    indicators.push({
      id: generateId(),
      type: 'tower_change',
      severity: 'medium',
      title: 'Unusual Tower Identifier',
      description: 'The connected tower has an unusual Location Area Code, which may indicate a fake base station.',
      timestamp: Date.now(),
      details: {
        lac: tower.lac,
        cellId: tower.cellId,
      },
    });
  }
  
  // Check for weak signal (could indicate distant fake tower)
  if (tower.signalStrength < -100) {
    indicators.push({
      id: generateId(),
      type: 'signal_anomaly',
      severity: 'low',
      title: 'Weak Signal Detected',
      description: 'Unusually weak signal strength may indicate connection to a distant or fake tower.',
      timestamp: Date.now(),
      details: {
        signalStrength: tower.signalStrength,
        threshold: -100,
      },
    });
  }
  
  return indicators;
}

// Calculate overall threat level
export function calculateThreatLevel(indicators: ThreatIndicator[]): ThreatLevel {
  if (indicators.length === 0) return 'safe';
  
  const hasHigh = indicators.some(i => i.severity === 'high' || i.severity === 'critical');
  const hasMedium = indicators.some(i => i.severity === 'medium');
  
  if (hasHigh) return 'high';
  if (hasMedium) return 'medium';
  return 'low';
}

// Generate mock security status
export function generateMockSecurityStatus(simulateThreat: boolean = false): SecurityStatus {
  const tower = generateMockCellTower(simulateThreat);
  const indicators = generateThreatIndicators(tower);
  
  return {
    overallThreat: calculateThreatLevel(indicators),
    activeThreats: indicators.length,
    lastScanTime: Date.now(),
    isScanning: false,
    indicators,
  };
}

// Device type names for display
const DEVICE_NAMES: Record<string, string[]> = {
  phone: ['iPhone', 'Galaxy', 'Pixel', 'OnePlus', 'Unknown Phone'],
  laptop: ['MacBook', 'ThinkPad', 'Dell XPS', 'Surface'],
  headphones: ['AirPods', 'Sony WH', 'Bose QC', 'Galaxy Buds'],
  watch: ['Apple Watch', 'Galaxy Watch', 'Fitbit'],
  tracker: ['AirTag', 'Tile', 'SmartTag', 'Chipolo'],
  car: ['Tesla', 'BMW', 'Mercedes', 'Audi'],
  unknown: ['Unknown Device'],
};

// Generate mock Bluetooth device
export function generateMockBluetoothDevice(
  isTracker: boolean = false,
  isSuspicious: boolean = false
): BluetoothDevice {
  const deviceTypes = isTracker 
    ? ['tracker'] 
    : ['phone', 'laptop', 'headphones', 'watch', 'car', 'unknown'];
  const deviceType = deviceTypes[randomInRange(0, deviceTypes.length - 1)] as BluetoothDevice['deviceType'];
  const names = DEVICE_NAMES[deviceType];
  
  const sightingCount = isSuspicious ? randomInRange(5, 20) : randomInRange(1, 3);
  const firstSeen = Date.now() - (isSuspicious ? randomInRange(86400000, 604800000) : randomInRange(60000, 3600000));
  
  let riskLevel: BluetoothDevice['riskLevel'] = 'low';
  if (isTracker) riskLevel = 'high';
  else if (isSuspicious) riskLevel = sightingCount > 10 ? 'high' : 'medium';
  else if (deviceType === 'unknown') riskLevel = 'unknown';
  
  return {
    id: generateId(),
    name: Math.random() > 0.2 ? names[randomInRange(0, names.length - 1)] : null,
    macAddress: Array.from({ length: 6 }, () => 
      randomInRange(0, 255).toString(16).padStart(2, '0').toUpperCase()
    ).join(':'),
    rssi: randomInRange(-90, -30),
    firstSeen,
    lastSeen: Date.now() - randomInRange(0, 300000),
    sightingCount,
    locations: ['home', 'work', 'commute'].slice(0, randomInRange(1, isSuspicious ? 3 : 1)),
    riskLevel,
    deviceType,
    isKnown: false,
    isIgnored: false,
  };
}

// Generate mock alert
export function generateMockAlert(
  type: Alert['type'] = 'cell_tower',
  severity: ThreatLevel = 'medium'
): Alert {
  const alertTemplates: Record<Alert['type'], { title: string; message: string }[]> = {
    cell_tower: [
      { title: '2G Downgrade Detected', message: 'Your connection was forced to an insecure 2G network.' },
      { title: 'Suspicious Tower', message: 'Connected to a tower with unusual characteristics.' },
      { title: 'Tower Change', message: 'Rapid tower switching detected in your area.' },
    ],
    bluetooth: [
      { title: 'Potential Tracker', message: 'An unknown Bluetooth tracker has been following you.' },
      { title: 'Suspicious Device', message: 'A device has been seen at multiple locations with you.' },
      { title: 'Unknown AirTag', message: 'An AirTag not registered to you is nearby.' },
    ],
    network: [
      { title: 'Encryption Disabled', message: 'Your cellular connection is not encrypted.' },
      { title: 'IMSI Request', message: 'An unusual IMSI request was detected.' },
    ],
    system: [
      { title: 'Scan Complete', message: 'Security scan completed successfully.' },
      { title: 'Background Mode', message: 'Sentinel Guard is monitoring in the background.' },
    ],
  };
  
  const templates = alertTemplates[type];
  const template = templates[randomInRange(0, templates.length - 1)];
  
  return {
    id: generateId(),
    type,
    severity,
    title: template.title,
    message: template.message,
    timestamp: Date.now() - randomInRange(0, 86400000),
    isRead: Math.random() > 0.5,
  };
}

// Generate initial mock data set
export function generateInitialMockData() {
  const tower = generateMockCellTower(false);
  const indicators = generateThreatIndicators(tower);
  
  const devices: BluetoothDevice[] = [
    generateMockBluetoothDevice(false, false),
    generateMockBluetoothDevice(false, false),
    generateMockBluetoothDevice(false, true), // Suspicious
    generateMockBluetoothDevice(true, true),  // Tracker
    generateMockBluetoothDevice(false, false),
  ];
  
  const alerts: Alert[] = [
    generateMockAlert('bluetooth', 'high'),
    generateMockAlert('cell_tower', 'medium'),
    generateMockAlert('system', 'safe'),
    generateMockAlert('network', 'low'),
  ];
  
  return {
    tower,
    securityStatus: {
      overallThreat: calculateThreatLevel(indicators),
      activeThreats: indicators.length,
      lastScanTime: Date.now(),
      isScanning: false,
      indicators,
    } as SecurityStatus,
    devices,
    alerts,
  };
}
