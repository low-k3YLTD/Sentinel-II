// Security and surveillance detection types

export type ThreatLevel = 'safe' | 'low' | 'medium' | 'high' | 'critical';

export type NetworkType = '2G' | '3G' | '4G' | '5G' | 'Unknown';

export interface CellTower {
  id: string;
  mcc: string; // Mobile Country Code
  mnc: string; // Mobile Network Code
  lac: string; // Location Area Code
  cellId: string; // Cell ID
  networkType: NetworkType;
  signalStrength: number; // dBm
  timestamp: number;
  isConnected: boolean;
}

export interface ThreatIndicator {
  id: string;
  type: 'downgrade' | 'tower_change' | 'imsi_request' | 'signal_anomaly' | 'encryption_disabled';
  severity: ThreatLevel;
  title: string;
  description: string;
  timestamp: number;
  details?: Record<string, string | number>;
}

export interface SecurityStatus {
  overallThreat: ThreatLevel;
  activeThreats: number;
  lastScanTime: number;
  isScanning: boolean;
  indicators: ThreatIndicator[];
}

export interface BluetoothDevice {
  id: string;
  name: string | null;
  macAddress: string;
  rssi: number; // Signal strength
  firstSeen: number;
  lastSeen: number;
  sightingCount: number;
  locations: string[]; // Location IDs where seen
  riskLevel: 'low' | 'medium' | 'high' | 'unknown';
  deviceType: 'phone' | 'laptop' | 'headphones' | 'watch' | 'tracker' | 'car' | 'unknown';
  isKnown: boolean;
  isIgnored: boolean;
}

export interface Alert {
  id: string;
  type: 'cell_tower' | 'bluetooth' | 'network' | 'system';
  severity: ThreatLevel;
  title: string;
  message: string;
  timestamp: number;
  isRead: boolean;
  details?: Record<string, string | number>;
  relatedEntityId?: string;
}

export interface GeoLocation {
  latitude: number;
  longitude: number;
  accuracy?: number;
  altitude?: number;
  timestamp: number;
}

export interface ThreatLocation {
  id: string;
  location: GeoLocation;
  threatType: 'cell_tower' | 'bluetooth' | 'network';
  severity: ThreatLevel;
  title: string;
  description: string;
  timestamp: number;
  relatedAlertId?: string;
  details?: Record<string, string | number>;
}

export interface ScanSession {
  id: string;
  startTime: number;
  endTime?: number;
  towersDetected: number;
  devicesDetected: number;
  alertsGenerated: number;
  status: 'active' | 'completed' | 'error';
}

export interface AppSettings {
  autoStartScanning: boolean;
  scanIntervalSeconds: number;
  enableBackgroundMode: boolean;
  notificationsEnabled: boolean;
  alertSoundEnabled: boolean;
  vibrationEnabled: boolean;
  dataRetentionDays: number;
  showUnknownDevices: boolean;
}

export const DEFAULT_SETTINGS: AppSettings = {
  autoStartScanning: true,
  scanIntervalSeconds: 30,
  enableBackgroundMode: false,
  notificationsEnabled: true,
  alertSoundEnabled: true,
  vibrationEnabled: true,
  dataRetentionDays: 30,
  showUnknownDevices: true,
};
