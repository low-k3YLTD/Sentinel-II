// Settings - App configuration

import React from 'react';
import { View, StyleSheet, ScrollView, Switch, Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';

import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { Colors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useSecurity } from '@/contexts/security-context';

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'dark'];
  
  const { settings, updateSettings, clearAlerts } = useSecurity();

  const SettingRow = ({
    icon,
    title,
    subtitle,
    value,
    onValueChange,
  }: {
    icon: string;
    title: string;
    subtitle?: string;
    value: boolean;
    onValueChange: (value: boolean) => void;
  }) => (
    <View style={[styles.settingRow, { backgroundColor: colors.surface }]}>
      <View style={[styles.settingIcon, { backgroundColor: `${colors.accent}20` }]}>
        <IconSymbol name={icon as any} size={20} color={colors.accent} />
      </View>
      <View style={styles.settingContent}>
        <ThemedText style={styles.settingTitle}>{title}</ThemedText>
        {subtitle && <ThemedText style={styles.settingSubtitle}>{subtitle}</ThemedText>}
      </View>
      <Switch
        value={value}
        onValueChange={(val) => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          onValueChange(val);
        }}
        trackColor={{ false: colors.border, true: colors.accent }}
        thumbColor="#FFFFFF"
      />
    </View>
  );

  const ActionRow = ({
    icon,
    title,
    subtitle,
    onPress,
    destructive,
  }: {
    icon: string;
    title: string;
    subtitle?: string;
    onPress: () => void;
    destructive?: boolean;
  }) => (
    <Pressable
      onPress={() => {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        onPress();
      }}
      style={({ pressed }) => [
        styles.settingRow,
        { backgroundColor: colors.surface },
        pressed && styles.pressed,
      ]}
    >
      <View style={[styles.settingIcon, { backgroundColor: destructive ? 'rgba(255, 59, 92, 0.1)' : `${colors.accent}20` }]}>
        <IconSymbol name={icon as any} size={20} color={destructive ? '#FF3B5C' : colors.accent} />
      </View>
      <View style={styles.settingContent}>
        <ThemedText style={[styles.settingTitle, destructive && { color: '#FF3B5C' }]}>{title}</ThemedText>
        {subtitle && <ThemedText style={styles.settingSubtitle}>{subtitle}</ThemedText>}
      </View>
      <IconSymbol name="chevron.right" size={16} color={colors.textSecondary} />
    </Pressable>
  );

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.content,
          { paddingTop: Math.max(insets.top, 20), paddingBottom: Math.max(insets.bottom, 20) + 100 },
        ]}
      >
        {/* Header */}
        <ThemedText type="title" style={styles.title}>Settings</ThemedText>

        {/* Monitoring Section */}
        <View style={styles.section}>
          <ThemedText style={styles.sectionTitle}>MONITORING</ThemedText>
          
          <SettingRow
            icon="play.fill"
            title="Auto-Start Scanning"
            subtitle="Begin monitoring when app opens"
            value={settings.autoStartScanning}
            onValueChange={(val) => updateSettings({ autoStartScanning: val })}
          />
          
          <SettingRow
            icon="arrow.clockwise"
            title="Background Mode"
            subtitle="Continue monitoring when app is closed"
            value={settings.enableBackgroundMode}
            onValueChange={(val) => updateSettings({ enableBackgroundMode: val })}
          />
          
          <SettingRow
            icon="eye.fill"
            title="Show Unknown Devices"
            subtitle="Display unidentified Bluetooth devices"
            value={settings.showUnknownDevices}
            onValueChange={(val) => updateSettings({ showUnknownDevices: val })}
          />
        </View>

        {/* Notifications Section */}
        <View style={styles.section}>
          <ThemedText style={styles.sectionTitle}>NOTIFICATIONS</ThemedText>
          
          <SettingRow
            icon="bell.fill"
            title="Push Notifications"
            subtitle="Receive alerts for security threats"
            value={settings.notificationsEnabled}
            onValueChange={(val) => updateSettings({ notificationsEnabled: val })}
          />
          
          <SettingRow
            icon="bell.badge.fill"
            title="Alert Sounds"
            subtitle="Play sound for high-priority alerts"
            value={settings.alertSoundEnabled}
            onValueChange={(val) => updateSettings({ alertSoundEnabled: val })}
          />
          
          <SettingRow
            icon="iphone"
            title="Vibration"
            subtitle="Vibrate for alerts"
            value={settings.vibrationEnabled}
            onValueChange={(val) => updateSettings({ vibrationEnabled: val })}
          />
        </View>

        {/* Privacy Section */}
        <View style={styles.section}>
          <ThemedText style={styles.sectionTitle}>PRIVACY & DATA</ThemedText>
          
          <ActionRow
            icon="trash.fill"
            title="Clear Alert History"
            subtitle="Remove all stored alerts"
            onPress={clearAlerts}
            destructive
          />
          
          <ActionRow
            icon="clock.fill"
            title="Data Retention"
            subtitle={`${settings.dataRetentionDays} days`}
            onPress={() => {
              // Toggle between 7, 14, 30 days
              const options = [7, 14, 30];
              const currentIndex = options.indexOf(settings.dataRetentionDays);
              const nextIndex = (currentIndex + 1) % options.length;
              updateSettings({ dataRetentionDays: options[nextIndex] });
            }}
          />
        </View>

        {/* About Section */}
        <View style={styles.section}>
          <ThemedText style={styles.sectionTitle}>ABOUT</ThemedText>
          
          <View style={[styles.aboutCard, { backgroundColor: colors.surface }]}>
            <View style={styles.appInfo}>
              <View style={[styles.appIcon, { backgroundColor: colors.accent }]}>
                <IconSymbol name="shield.fill" size={32} color="#FFFFFF" />
              </View>
              <View>
                <ThemedText style={styles.appName}>Sentinel Guard</ThemedText>
                <ThemedText style={styles.appVersion}>Version 1.0.0</ThemedText>
              </View>
            </View>
            <ThemedText style={styles.appDescription}>
              Counter-intelligence app for detecting fake cell towers, IMSI catchers, 
              and Bluetooth tracking devices. Protect your privacy and stay aware of 
              surveillance threats.
            </ThemedText>
          </View>
        </View>

        {/* Info Card */}
        <View style={[styles.infoCard, { backgroundColor: colors.surface }]}>
          <IconSymbol name="info.circle.fill" size={20} color={colors.info} />
          <View style={styles.infoContent}>
            <ThemedText style={styles.infoTitle}>Disclaimer</ThemedText>
            <ThemedText style={styles.infoText}>
              This app provides simulated threat detection for educational purposes. 
              Real IMSI catcher detection requires specialized hardware and root access.
            </ThemedText>
          </View>
        </View>
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 28,
    lineHeight: 34,
    marginBottom: 24,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: '#6B7280',
    letterSpacing: 1,
    marginBottom: 12,
    marginLeft: 4,
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 16,
    marginBottom: 8,
  },
  pressed: {
    opacity: 0.8,
  },
  settingIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  settingContent: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '500',
  },
  settingSubtitle: {
    fontSize: 13,
    color: '#9CA3AF',
    marginTop: 2,
  },
  aboutCard: {
    borderRadius: 16,
    padding: 20,
  },
  appInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    marginBottom: 16,
  },
  appIcon: {
    width: 64,
    height: 64,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  appName: {
    fontSize: 20,
    fontWeight: '700',
  },
  appVersion: {
    fontSize: 14,
    color: '#9CA3AF',
    marginTop: 2,
  },
  appDescription: {
    fontSize: 14,
    color: '#9CA3AF',
    lineHeight: 22,
  },
  infoCard: {
    flexDirection: 'row',
    borderRadius: 12,
    padding: 16,
    gap: 12,
    marginBottom: 24,
  },
  infoContent: {
    flex: 1,
  },
  infoTitle: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  infoText: {
    fontSize: 13,
    color: '#9CA3AF',
    lineHeight: 20,
  },
});
