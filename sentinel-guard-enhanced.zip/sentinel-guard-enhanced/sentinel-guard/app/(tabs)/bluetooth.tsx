// Bluetooth Scanner - Device tracking detection

import React, { useState } from 'react';
import { View, StyleSheet, FlatList, Pressable, RefreshControl } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';

import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { Colors, ThreatColors, RiskColors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useSecurity } from '@/contexts/security-context';
import { BluetoothDevice } from '@/types/security';

type FilterType = 'all' | 'suspicious' | 'trackers' | 'unknown';

export default function BluetoothScreen() {
  const insets = useSafeAreaInsets();
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'dark'];
  
  const { devices, isScanning, startScan, stopScan, markDeviceKnown, markDeviceIgnored } = useSecurity();
  const [filter, setFilter] = useState<FilterType>('all');
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = React.useCallback(async () => {
    setRefreshing(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setTimeout(() => setRefreshing(false), 1000);
  }, []);

  const filteredDevices = devices.filter(device => {
    if (device.isIgnored) return false;
    switch (filter) {
      case 'suspicious':
        return device.riskLevel === 'high' || device.riskLevel === 'medium';
      case 'trackers':
        return device.deviceType === 'tracker';
      case 'unknown':
        return device.riskLevel === 'unknown' || !device.name;
      default:
        return true;
    }
  });

  const getDeviceIcon = (type: BluetoothDevice['deviceType']) => {
    switch (type) {
      case 'phone': return 'iphone';
      case 'laptop': return 'laptopcomputer';
      case 'headphones': return 'headphones';
      case 'watch': return 'applewatch';
      case 'tracker': return 'tag.fill';
      case 'car': return 'car.fill';
      default: return 'questionmark.circle.fill';
    }
  };

  const formatTime = (timestamp: number) => {
    const diff = Date.now() - timestamp;
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return `${Math.floor(diff / 86400000)}d ago`;
  };

  const renderDevice = ({ item }: { item: BluetoothDevice }) => (
    <View style={[styles.deviceCard, { backgroundColor: colors.surface }]}>
      <View style={[styles.deviceIcon, { backgroundColor: `${RiskColors[item.riskLevel]}20` }]}>
        <IconSymbol
          name={getDeviceIcon(item.deviceType) as any}
          size={24}
          color={RiskColors[item.riskLevel]}
        />
      </View>
      
      <View style={styles.deviceInfo}>
        <View style={styles.deviceHeader}>
          <ThemedText style={styles.deviceName} numberOfLines={1}>
            {item.name || 'Unknown Device'}
          </ThemedText>
          <View style={[styles.riskBadge, { backgroundColor: `${RiskColors[item.riskLevel]}20` }]}>
            <ThemedText style={[styles.riskText, { color: RiskColors[item.riskLevel] }]}>
              {item.riskLevel.toUpperCase()}
            </ThemedText>
          </View>
        </View>
        
        <ThemedText style={styles.macAddress}>{item.macAddress}</ThemedText>
        
        <View style={styles.deviceMeta}>
          <View style={styles.metaItem}>
            <IconSymbol name="clock.fill" size={12} color="#6B7280" />
            <ThemedText style={styles.metaText}>Last: {formatTime(item.lastSeen)}</ThemedText>
          </View>
          <View style={styles.metaItem}>
            <IconSymbol name="eye.fill" size={12} color="#6B7280" />
            <ThemedText style={styles.metaText}>{item.sightingCount} sightings</ThemedText>
          </View>
        </View>
        
        {item.riskLevel === 'high' && (
          <View style={styles.warningBanner}>
            <ThemedText style={styles.warningText}>
              ⚠️ This device has been seen following you across {item.locations.length} locations
            </ThemedText>
          </View>
        )}
      </View>
      
      <View style={styles.signalIndicator}>
        <ThemedText style={styles.rssiValue}>{item.rssi}</ThemedText>
        <ThemedText style={styles.rssiLabel}>dBm</ThemedText>
      </View>
    </View>
  );

  const FilterChip = ({ type, label }: { type: FilterType; label: string }) => (
    <Pressable
      onPress={() => {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        setFilter(type);
      }}
      style={[
        styles.filterChip,
        filter === type
          ? { backgroundColor: colors.accent }
          : { backgroundColor: colors.surface },
      ]}
    >
      <ThemedText
        style={[
          styles.filterText,
          filter === type ? { color: '#FFFFFF' } : { color: colors.textSecondary },
        ]}
      >
        {label}
      </ThemedText>
    </Pressable>
  );

  return (
    <ThemedView style={styles.container}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: Math.max(insets.top, 20) }]}>
        <ThemedText type="title" style={styles.title}>Bluetooth Scanner</ThemedText>
        <ThemedText style={styles.subtitle}>
          Monitoring for tracking devices and suspicious Bluetooth activity
        </ThemedText>

        {/* Scan Button */}
        <Pressable
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            isScanning ? stopScan() : startScan();
          }}
          style={[
            styles.scanButton,
            { backgroundColor: isScanning ? ThreatColors.medium : colors.accentSecondary },
          ]}
        >
          <IconSymbol
            name={isScanning ? 'stop.fill' : 'bluetooth'}
            size={20}
            color="#FFFFFF"
          />
          <ThemedText style={styles.scanButtonText}>
            {isScanning ? 'Stop Scan' : 'Start Scan'}
          </ThemedText>
        </Pressable>

        {/* Filter Chips */}
        <View style={styles.filterRow}>
          <FilterChip type="all" label="All" />
          <FilterChip type="suspicious" label="Suspicious" />
          <FilterChip type="trackers" label="Trackers" />
          <FilterChip type="unknown" label="Unknown" />
        </View>
      </View>

      {/* Device List */}
      <FlatList
        data={filteredDevices}
        keyExtractor={(item) => item.id}
        renderItem={renderDevice}
        contentContainerStyle={[
          styles.listContent,
          { paddingBottom: Math.max(insets.bottom, 20) + 100 },
        ]}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.accent}
          />
        }
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <IconSymbol name="bluetooth" size={48} color={colors.textSecondary} />
            <ThemedText style={styles.emptyTitle}>No devices found</ThemedText>
            <ThemedText style={styles.emptySubtext}>
              {isScanning ? 'Scanning for nearby devices...' : 'Start a scan to detect nearby Bluetooth devices'}
            </ThemedText>
          </View>
        }
      />
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  title: {
    fontSize: 28,
    lineHeight: 34,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: '#9CA3AF',
    marginBottom: 16,
  },
  scanButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
    gap: 8,
    marginBottom: 16,
  },
  scanButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '600',
  },
  filterRow: {
    flexDirection: 'row',
    gap: 8,
  },
  filterChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  filterText: {
    fontSize: 13,
    fontWeight: '500',
  },
  listContent: {
    paddingHorizontal: 20,
  },
  deviceCard: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    padding: 16,
    borderRadius: 16,
    marginBottom: 12,
  },
  deviceIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  deviceInfo: {
    flex: 1,
  },
  deviceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  deviceName: {
    fontSize: 16,
    fontWeight: '600',
    flex: 1,
  },
  riskBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
  },
  riskText: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  macAddress: {
    fontSize: 12,
    color: '#6B7280',
    fontFamily: 'monospace',
    marginBottom: 8,
  },
  deviceMeta: {
    flexDirection: 'row',
    gap: 16,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metaText: {
    fontSize: 11,
    color: '#6B7280',
  },
  warningBanner: {
    marginTop: 8,
    padding: 8,
    backgroundColor: 'rgba(255, 59, 92, 0.1)',
    borderRadius: 8,
  },
  warningText: {
    fontSize: 12,
    color: '#FF3B5C',
  },
  signalIndicator: {
    alignItems: 'center',
    marginLeft: 8,
  },
  rssiValue: {
    fontSize: 16,
    fontWeight: '700',
  },
  rssiLabel: {
    fontSize: 10,
    color: '#6B7280',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#9CA3AF',
    marginTop: 8,
    textAlign: 'center',
    paddingHorizontal: 40,
  },
});
