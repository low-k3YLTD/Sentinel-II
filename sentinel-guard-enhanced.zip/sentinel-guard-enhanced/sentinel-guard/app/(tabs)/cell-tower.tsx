// Cell Tower Monitor - Detailed cell tower analysis

import React from 'react';
import { View, StyleSheet, ScrollView, RefreshControl } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';

import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { Colors, ThreatColors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useSecurity } from '@/contexts/security-context';
import { ThreatIndicator } from '@/types/security';

export default function CellTowerScreen() {
  const insets = useSafeAreaInsets();
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'dark'];
  
  const { currentTower, securityStatus, refreshData } = useSecurity();
  const [refreshing, setRefreshing] = React.useState(false);

  const onRefresh = React.useCallback(async () => {
    setRefreshing(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    refreshData();
    setTimeout(() => setRefreshing(false), 1000);
  }, [refreshData]);

  const getSignalBars = (strength: number) => {
    if (strength >= -70) return 4;
    if (strength >= -85) return 3;
    if (strength >= -100) return 2;
    return 1;
  };

  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getIndicatorIcon = (type: ThreatIndicator['type']) => {
    switch (type) {
      case 'downgrade': return 'antenna.radiowaves.left.and.right.slash';
      case 'tower_change': return 'exclamationmark.triangle.fill';
      case 'imsi_request': return 'eye.fill';
      case 'signal_anomaly': return 'cellularbars';
      case 'encryption_disabled': return 'xmark.shield.fill';
      default: return 'info.circle.fill';
    }
  };

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.content,
          { paddingTop: Math.max(insets.top, 20), paddingBottom: Math.max(insets.bottom, 20) + 100 },
        ]}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.accent}
          />
        }
      >
        {/* Header */}
        <ThemedText type="title" style={styles.title}>Cell Tower Monitor</ThemedText>
        <ThemedText style={styles.subtitle}>
          Analyzing connected cell tower for suspicious activity
        </ThemedText>

        {/* Current Tower Card */}
        {currentTower ? (
          <View style={[styles.towerCard, { backgroundColor: colors.surface }]}>
            <View style={styles.towerHeader}>
              <View style={[styles.statusBadge, { backgroundColor: `${ThreatColors[securityStatus.overallThreat]}20` }]}>
                <View style={[styles.statusDot, { backgroundColor: ThreatColors[securityStatus.overallThreat] }]} />
                <ThemedText style={[styles.statusText, { color: ThreatColors[securityStatus.overallThreat] }]}>
                  {securityStatus.overallThreat.toUpperCase()}
                </ThemedText>
              </View>
              <ThemedText style={styles.lastUpdate}>
                Updated {formatTime(currentTower.timestamp)}
              </ThemedText>
            </View>

            {/* Network Type */}
            <View style={styles.networkSection}>
              <View style={[
                styles.networkBadge,
                { backgroundColor: currentTower.networkType === '2G' ? `${ThreatColors.high}20` : `${colors.accent}20` }
              ]}>
                <ThemedText style={[
                  styles.networkType,
                  { color: currentTower.networkType === '2G' ? ThreatColors.high : colors.accent }
                ]}>
                  {currentTower.networkType}
                </ThemedText>
              </View>
              {currentTower.networkType === '2G' && (
                <ThemedText style={[styles.warningText, { color: ThreatColors.high }]}>
                  ⚠️ Insecure network - vulnerable to interception
                </ThemedText>
              )}
            </View>

            {/* Signal Strength */}
            <View style={styles.signalSection}>
              <ThemedText style={styles.sectionLabel}>Signal Strength</ThemedText>
              <View style={styles.signalRow}>
                <View style={styles.signalBars}>
                  {[1, 2, 3, 4].map((bar) => (
                    <View
                      key={bar}
                      style={[
                        styles.signalBar,
                        { height: 8 + bar * 6 },
                        bar <= getSignalBars(currentTower.signalStrength)
                          ? { backgroundColor: colors.accent }
                          : { backgroundColor: colors.border },
                      ]}
                    />
                  ))}
                </View>
                <ThemedText style={styles.signalValue}>{currentTower.signalStrength} dBm</ThemedText>
              </View>
            </View>

            {/* Tower Details Grid */}
            <View style={styles.detailsGrid}>
              <View style={styles.detailItem}>
                <ThemedText style={styles.detailLabel}>MCC</ThemedText>
                <ThemedText style={styles.detailValue}>{currentTower.mcc}</ThemedText>
              </View>
              <View style={styles.detailItem}>
                <ThemedText style={styles.detailLabel}>MNC</ThemedText>
                <ThemedText style={styles.detailValue}>{currentTower.mnc}</ThemedText>
              </View>
              <View style={styles.detailItem}>
                <ThemedText style={styles.detailLabel}>LAC</ThemedText>
                <ThemedText style={[
                  styles.detailValue,
                  (currentTower.lac === '0000' || currentTower.lac === 'FFFF') && { color: ThreatColors.medium }
                ]}>
                  {currentTower.lac}
                </ThemedText>
              </View>
              <View style={styles.detailItem}>
                <ThemedText style={styles.detailLabel}>Cell ID</ThemedText>
                <ThemedText style={styles.detailValue}>{currentTower.cellId}</ThemedText>
              </View>
            </View>
          </View>
        ) : (
          <View style={[styles.emptyCard, { backgroundColor: colors.surface }]}>
            <IconSymbol name="antenna.radiowaves.left.and.right" size={48} color={colors.textSecondary} />
            <ThemedText style={styles.emptyText}>No cell tower data available</ThemedText>
            <ThemedText style={styles.emptySubtext}>Pull down to refresh</ThemedText>
          </View>
        )}

        {/* Threat Indicators */}
        <View style={styles.indicatorsSection}>
          <ThemedText type="subtitle" style={styles.sectionTitle}>Threat Indicators</ThemedText>
          
          {securityStatus.indicators.length > 0 ? (
            securityStatus.indicators.map((indicator) => (
              <View
                key={indicator.id}
                style={[
                  styles.indicatorCard,
                  { backgroundColor: colors.surface, borderLeftColor: ThreatColors[indicator.severity] },
                ]}
              >
                <View style={styles.indicatorHeader}>
                  <IconSymbol
                    name={getIndicatorIcon(indicator.type) as any}
                    size={20}
                    color={ThreatColors[indicator.severity]}
                  />
                  <ThemedText style={styles.indicatorTitle}>{indicator.title}</ThemedText>
                </View>
                <ThemedText style={styles.indicatorDescription}>{indicator.description}</ThemedText>
                <ThemedText style={styles.indicatorTime}>{formatTime(indicator.timestamp)}</ThemedText>
              </View>
            ))
          ) : (
            <View style={[styles.noThreatsCard, { backgroundColor: colors.surface }]}>
              <IconSymbol name="checkmark.shield.fill" size={32} color={ThreatColors.safe} />
              <ThemedText style={[styles.noThreatsText, { color: ThreatColors.safe }]}>
                No threats detected
              </ThemedText>
              <ThemedText style={styles.noThreatsSubtext}>
                Your connection appears secure
              </ThemedText>
            </View>
          )}
        </View>

        {/* Info Section */}
        <View style={[styles.infoCard, { backgroundColor: colors.surface }]}>
          <IconSymbol name="info.circle.fill" size={20} color={colors.info} />
          <View style={styles.infoContent}>
            <ThemedText style={styles.infoTitle}>About IMSI Catchers</ThemedText>
            <ThemedText style={styles.infoText}>
              IMSI catchers (Stingrays) are fake cell towers that intercept mobile communications. 
              They often force phones to downgrade to 2G, which lacks encryption.
            </ThemedText>
          </View>
        </View>
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 28,
    lineHeight: 34,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: '#9CA3AF',
    marginBottom: 24,
  },
  towerCard: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  towerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    gap: 6,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1,
  },
  lastUpdate: {
    fontSize: 12,
    color: '#6B7280',
  },
  networkSection: {
    marginBottom: 20,
  },
  networkBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 12,
    marginBottom: 8,
  },
  networkType: {
    fontSize: 24,
    fontWeight: '700',
  },
  warningText: {
    fontSize: 13,
  },
  signalSection: {
    marginBottom: 20,
  },
  sectionLabel: {
    fontSize: 12,
    color: '#9CA3AF',
    marginBottom: 8,
  },
  signalRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 16,
  },
  signalBars: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 4,
  },
  signalBar: {
    width: 8,
    borderRadius: 2,
  },
  signalValue: {
    fontSize: 18,
    fontWeight: '600',
  },
  detailsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  detailItem: {
    width: '45%',
  },
  detailLabel: {
    fontSize: 12,
    color: '#9CA3AF',
    marginBottom: 4,
  },
  detailValue: {
    fontSize: 16,
    fontWeight: '600',
    fontFamily: 'monospace',
  },
  emptyCard: {
    borderRadius: 16,
    padding: 40,
    alignItems: 'center',
    marginBottom: 24,
  },
  emptyText: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#9CA3AF',
    marginTop: 4,
  },
  indicatorsSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    lineHeight: 24,
    marginBottom: 12,
  },
  indicatorCard: {
    borderRadius: 12,
    padding: 16,
    borderLeftWidth: 3,
    marginBottom: 12,
  },
  indicatorHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  indicatorTitle: {
    fontSize: 15,
    fontWeight: '600',
    flex: 1,
  },
  indicatorDescription: {
    fontSize: 13,
    color: '#9CA3AF',
    lineHeight: 20,
    marginBottom: 8,
  },
  indicatorTime: {
    fontSize: 11,
    color: '#6B7280',
  },
  noThreatsCard: {
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
  },
  noThreatsText: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: 12,
  },
  noThreatsSubtext: {
    fontSize: 13,
    color: '#9CA3AF',
    marginTop: 4,
  },
  infoCard: {
    flexDirection: 'row',
    borderRadius: 12,
    padding: 16,
    gap: 12,
  },
  infoContent: {
    flex: 1,
  },
  infoTitle: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  infoText: {
    fontSize: 13,
    color: '#9CA3AF',
    lineHeight: 20,
  },
});
