// Alerts History - Security alert log

import React, { useState } from 'react';
import { View, StyleSheet, FlatList, Pressable, RefreshControl } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';

import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { Colors, ThreatColors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useSecurity } from '@/contexts/security-context';
import { Alert } from '@/types/security';

type FilterType = 'all' | 'cell_tower' | 'bluetooth' | 'network';

export default function AlertsScreen() {
  const insets = useSafeAreaInsets();
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'dark'];
  
  const { alerts, markAlertRead, clearAlerts } = useSecurity();
  const [filter, setFilter] = useState<FilterType>('all');
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = React.useCallback(async () => {
    setRefreshing(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setTimeout(() => setRefreshing(false), 1000);
  }, []);

  const filteredAlerts = alerts.filter(alert => {
    if (filter === 'all') return true;
    return alert.type === filter;
  });

  const getAlertIcon = (type: Alert['type']) => {
    switch (type) {
      case 'cell_tower': return 'antenna.radiowaves.left.and.right';
      case 'bluetooth': return 'bluetooth';
      case 'network': return 'network';
      case 'system': return 'gearshape.fill';
      default: return 'info.circle.fill';
    }
  };

  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - timestamp;
    
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    
    if (date.toDateString() === now.toDateString()) {
      return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    }
    
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const renderAlert = ({ item }: { item: Alert }) => (
    <Pressable
      onPress={() => {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        markAlertRead(item.id);
      }}
      style={[
        styles.alertCard,
        { backgroundColor: colors.surface, borderLeftColor: ThreatColors[item.severity] },
        !item.isRead && styles.unreadCard,
      ]}
    >
      <View style={[styles.alertIcon, { backgroundColor: `${ThreatColors[item.severity]}20` }]}>
        <IconSymbol
          name={getAlertIcon(item.type) as any}
          size={20}
          color={ThreatColors[item.severity]}
        />
      </View>
      
      <View style={styles.alertContent}>
        <View style={styles.alertHeader}>
          <ThemedText style={styles.alertTitle}>{item.title}</ThemedText>
          {!item.isRead && <View style={[styles.unreadDot, { backgroundColor: colors.accent }]} />}
        </View>
        <ThemedText style={styles.alertMessage} numberOfLines={2}>
          {item.message}
        </ThemedText>
        <View style={styles.alertMeta}>
          <View style={[styles.severityBadge, { backgroundColor: `${ThreatColors[item.severity]}20` }]}>
            <ThemedText style={[styles.severityText, { color: ThreatColors[item.severity] }]}>
              {item.severity.toUpperCase()}
            </ThemedText>
          </View>
          <ThemedText style={styles.alertTime}>{formatTime(item.timestamp)}</ThemedText>
        </View>
      </View>
    </Pressable>
  );

  const FilterChip = ({ type, label }: { type: FilterType; label: string }) => (
    <Pressable
      onPress={() => {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        setFilter(type);
      }}
      style={[
        styles.filterChip,
        filter === type
          ? { backgroundColor: colors.accent }
          : { backgroundColor: colors.surface },
      ]}
    >
      <ThemedText
        style={[
          styles.filterText,
          filter === type ? { color: '#FFFFFF' } : { color: colors.textSecondary },
        ]}
      >
        {label}
      </ThemedText>
    </Pressable>
  );

  const unreadCount = alerts.filter(a => !a.isRead).length;

  return (
    <ThemedView style={styles.container}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: Math.max(insets.top, 20) }]}>
        <View style={styles.headerRow}>
          <View>
            <ThemedText type="title" style={styles.title}>Alerts</ThemedText>
            <ThemedText style={styles.subtitle}>
              {unreadCount > 0 ? `${unreadCount} unread alert${unreadCount > 1 ? 's' : ''}` : 'All caught up'}
            </ThemedText>
          </View>
          {alerts.length > 0 && (
            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                clearAlerts();
              }}
              style={styles.clearButton}
            >
              <IconSymbol name="trash.fill" size={16} color={ThreatColors.high} />
              <ThemedText style={[styles.clearText, { color: ThreatColors.high }]}>Clear</ThemedText>
            </Pressable>
          )}
        </View>

        {/* Filter Chips */}
        <View style={styles.filterRow}>
          <FilterChip type="all" label="All" />
          <FilterChip type="cell_tower" label="Cell Tower" />
          <FilterChip type="bluetooth" label="Bluetooth" />
          <FilterChip type="network" label="Network" />
        </View>
      </View>

      {/* Alert List */}
      <FlatList
        data={filteredAlerts}
        keyExtractor={(item) => item.id}
        renderItem={renderAlert}
        contentContainerStyle={[
          styles.listContent,
          { paddingBottom: Math.max(insets.bottom, 20) + 100 },
        ]}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.accent}
          />
        }
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <IconSymbol name="bell.fill" size={48} color={colors.textSecondary} />
            <ThemedText style={styles.emptyTitle}>No alerts</ThemedText>
            <ThemedText style={styles.emptySubtext}>
              {filter === 'all' 
                ? 'You have no security alerts. Keep monitoring to stay protected.'
                : `No ${filter.replace('_', ' ')} alerts found.`}
            </ThemedText>
          </View>
        }
      />
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  title: {
    fontSize: 28,
    lineHeight: 34,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: '#9CA3AF',
  },
  clearButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 59, 92, 0.1)',
  },
  clearText: {
    fontSize: 13,
    fontWeight: '500',
  },
  filterRow: {
    flexDirection: 'row',
    gap: 8,
  },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
  },
  filterText: {
    fontSize: 13,
    fontWeight: '500',
  },
  listContent: {
    paddingHorizontal: 20,
  },
  alertCard: {
    flexDirection: 'row',
    padding: 16,
    borderRadius: 16,
    borderLeftWidth: 3,
    marginBottom: 12,
  },
  unreadCard: {
    borderWidth: 1,
    borderColor: 'rgba(0, 212, 170, 0.3)',
  },
  alertIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  alertContent: {
    flex: 1,
  },
  alertHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  alertTitle: {
    fontSize: 15,
    fontWeight: '600',
    flex: 1,
  },
  unreadDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  alertMessage: {
    fontSize: 13,
    color: '#9CA3AF',
    lineHeight: 20,
    marginBottom: 8,
  },
  alertMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  severityBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
  },
  severityText: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  alertTime: {
    fontSize: 11,
    color: '#6B7280',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#9CA3AF',
    marginTop: 8,
    textAlign: 'center',
    paddingHorizontal: 40,
  },
});
