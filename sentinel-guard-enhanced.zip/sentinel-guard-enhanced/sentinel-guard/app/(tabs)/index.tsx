// Dashboard - Main screen showing security status

import React from 'react';
import { View, StyleSheet, ScrollView, Pressable, RefreshControl } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';

import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { ThreatStatusRing } from '@/components/threat-status-ring';
import { StatCard } from '@/components/stat-card';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { Colors, ThreatColors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useSecurity } from '@/contexts/security-context';

export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'dark'];
  
  const {
    securityStatus,
    currentTower,
    devices,
    alerts,
    isScanning,
    startScan,
    stopScan,
    refreshData,
    simulateThreat,
  } = useSecurity();

  const [refreshing, setRefreshing] = React.useState(false);

  const onRefresh = React.useCallback(async () => {
    setRefreshing(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    refreshData();
    setTimeout(() => setRefreshing(false), 1000);
  }, [refreshData]);

  const handleScanToggle = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    if (isScanning) {
      stopScan();
    } else {
      startScan();
    }
  };

  const unreadAlerts = alerts.filter(a => !a.isRead).length;
  const suspiciousDevices = devices.filter(d => d.riskLevel === 'high' || d.riskLevel === 'medium').length;
  
  const formatTime = (timestamp: number) => {
    const diff = Date.now() - timestamp;
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    return `${Math.floor(diff / 3600000)}h ago`;
  };

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.content,
          { paddingTop: Math.max(insets.top, 20), paddingBottom: Math.max(insets.bottom, 20) + 100 },
        ]}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.accent}
          />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <ThemedText type="title" style={styles.title}>Sentinel Guard</ThemedText>
          <Pressable onPress={simulateThreat} style={styles.testButton}>
            <ThemedText style={styles.testButtonText}>Test</ThemedText>
          </Pressable>
        </View>

        {/* Threat Status Ring */}
        <View style={styles.statusContainer}>
          <ThreatStatusRing
            threatLevel={securityStatus.overallThreat}
            isScanning={isScanning}
            size={220}
          />
        </View>

        {/* Scan Button */}
        <Pressable
          onPress={handleScanToggle}
          style={({ pressed }) => [
            styles.scanButton,
            { backgroundColor: isScanning ? ThreatColors.medium : colors.accent },
            pressed && styles.scanButtonPressed,
          ]}
        >
          <IconSymbol
            name={isScanning ? 'stop.fill' : 'play.fill'}
            size={20}
            color="#FFFFFF"
          />
          <ThemedText style={styles.scanButtonText}>
            {isScanning ? 'Stop Monitoring' : 'Start Monitoring'}
          </ThemedText>
        </Pressable>

        {/* Quick Stats */}
        <View style={styles.statsGrid}>
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <StatCard
                icon="exclamationmark.triangle.fill"
                label="Active Threats"
                value={securityStatus.activeThreats}
                color={securityStatus.activeThreats > 0 ? ThreatColors.high : ThreatColors.safe}
                onPress={() => router.push('/(tabs)/cell-tower')}
              />
            </View>
            <View style={styles.statItem}>
              <StatCard
                icon="dot.radiowaves.left.and.right"
                label="Devices Tracked"
                value={devices.length}
                color={colors.accentSecondary}
                onPress={() => router.push('/(tabs)/bluetooth')}
              />
            </View>
          </View>
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <StatCard
                icon="bell.badge.fill"
                label="Unread Alerts"
                value={unreadAlerts}
                color={unreadAlerts > 0 ? ThreatColors.medium : colors.textSecondary}
                onPress={() => router.push('/(tabs)/alerts')}
              />
            </View>
            <View style={styles.statItem}>
              <StatCard
                icon="clock.fill"
                label="Last Scan"
                value={formatTime(securityStatus.lastScanTime)}
                color={colors.textSecondary}
              />
            </View>
          </View>
        </View>

        {/* Current Tower Info */}
        {currentTower && (
          <Pressable
            onPress={() => router.push('/(tabs)/cell-tower')}
            style={({ pressed }) => [
              styles.towerCard,
              { backgroundColor: colors.surface },
              pressed && styles.cardPressed,
            ]}
          >
            <View style={styles.towerHeader}>
              <IconSymbol name="antenna.radiowaves.left.and.right" size={20} color={colors.accent} />
              <ThemedText style={styles.towerTitle}>Current Cell Tower</ThemedText>
              <IconSymbol name="chevron.right" size={16} color={colors.textSecondary} />
            </View>
            <View style={styles.towerDetails}>
              <View style={styles.towerDetail}>
                <ThemedText style={styles.towerLabel}>Network</ThemedText>
                <ThemedText style={[
                  styles.towerValue,
                  currentTower.networkType === '2G' && { color: ThreatColors.high }
                ]}>
                  {currentTower.networkType}
                </ThemedText>
              </View>
              <View style={styles.towerDetail}>
                <ThemedText style={styles.towerLabel}>Signal</ThemedText>
                <ThemedText style={styles.towerValue}>{currentTower.signalStrength} dBm</ThemedText>
              </View>
              <View style={styles.towerDetail}>
                <ThemedText style={styles.towerLabel}>Cell ID</ThemedText>
                <ThemedText style={styles.towerValue}>{currentTower.cellId}</ThemedText>
              </View>
            </View>
          </Pressable>
        )}

        {/* Recent Alerts Preview */}
        {alerts.length > 0 && (
          <View style={styles.alertsSection}>
            <View style={styles.sectionHeader}>
              <ThemedText type="subtitle" style={styles.sectionTitle}>Recent Alerts</ThemedText>
              <Pressable onPress={() => router.push('/(tabs)/alerts')}>
                <ThemedText style={[styles.seeAll, { color: colors.accent }]}>See All</ThemedText>
              </Pressable>
            </View>
            {alerts.slice(0, 3).map((alert) => (
              <View
                key={alert.id}
                style={[
                  styles.alertItem,
                  { backgroundColor: colors.surface, borderLeftColor: ThreatColors[alert.severity] },
                ]}
              >
                <View style={styles.alertContent}>
                  <ThemedText style={styles.alertTitle}>{alert.title}</ThemedText>
                  <ThemedText style={styles.alertMessage} numberOfLines={1}>
                    {alert.message}
                  </ThemedText>
                </View>
                <ThemedText style={styles.alertTime}>{formatTime(alert.timestamp)}</ThemedText>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 28,
    lineHeight: 34,
  },
  testButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  testButtonText: {
    fontSize: 12,
    color: '#9CA3AF',
  },
  statusContainer: {
    alignItems: 'center',
    marginBottom: 24,
  },
  scanButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 16,
    gap: 8,
    marginBottom: 24,
  },
  scanButtonPressed: {
    opacity: 0.9,
    transform: [{ scale: 0.98 }],
  },
  scanButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  statsGrid: {
    gap: 12,
    marginBottom: 24,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 12,
  },
  statItem: {
    flex: 1,
  },
  towerCard: {
    padding: 16,
    borderRadius: 16,
    marginBottom: 24,
  },
  cardPressed: {
    opacity: 0.9,
  },
  towerHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  towerTitle: {
    flex: 1,
    fontSize: 16,
    fontWeight: '600',
  },
  towerDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  towerDetail: {
    alignItems: 'center',
  },
  towerLabel: {
    fontSize: 12,
    color: '#9CA3AF',
    marginBottom: 4,
  },
  towerValue: {
    fontSize: 16,
    fontWeight: '600',
  },
  alertsSection: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    lineHeight: 24,
  },
  seeAll: {
    fontSize: 14,
    fontWeight: '500',
  },
  alertItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 12,
    borderLeftWidth: 3,
    marginBottom: 8,
  },
  alertContent: {
    flex: 1,
  },
  alertTitle: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 2,
  },
  alertMessage: {
    fontSize: 12,
    color: '#9CA3AF',
  },
  alertTime: {
    fontSize: 11,
    color: '#6B7280',
  },
});
