// Threat Map Screen - Location-based threat history visualization

import React, { useState, useMemo } from 'react';
import {
  View,
  StyleSheet,
  Pressable,
  ScrollView,
  Modal,
  Dimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { useSecurity } from '@/contexts/security-context';
import { ThreatLocation, ThreatLevel } from '@/types/security';
import { Colors, ThreatColors } from '@/constants/theme';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

// Map dimensions for the simulated map view
const MAP_WIDTH = SCREEN_WIDTH - 32;
const MAP_HEIGHT = 400;

// Convert lat/lng to map coordinates (simplified projection)
const latLngToMapCoords = (
  lat: number,
  lng: number,
  bounds: { minLat: number; maxLat: number; minLng: number; maxLng: number }
) => {
  const x = ((lng - bounds.minLng) / (bounds.maxLng - bounds.minLng)) * MAP_WIDTH;
  const y = ((bounds.maxLat - lat) / (bounds.maxLat - bounds.minLat)) * MAP_HEIGHT;
  return { x: Math.max(10, Math.min(MAP_WIDTH - 10, x)), y: Math.max(10, Math.min(MAP_HEIGHT - 10, y)) };
};

// Get marker color based on severity
const getMarkerColor = (severity: ThreatLevel): string => {
  switch (severity) {
    case 'critical': return ThreatColors.critical;
    case 'high': return ThreatColors.high;
    case 'medium': return ThreatColors.medium;
    case 'low': return ThreatColors.low;
    default: return ThreatColors.safe;
  }
};

// Get marker icon based on threat type
const getMarkerIcon = (threatType: string): string => {
  switch (threatType) {
    case 'cell_tower': return '📡';
    case 'bluetooth': return '📱';
    case 'network': return '🌐';
    default: return '⚠️';
  }
};

// Format timestamp to relative time
const formatTimeAgo = (timestamp: number): string => {
  const seconds = Math.floor((Date.now() - timestamp) / 1000);
  if (seconds < 60) return 'Just now';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
};

// Filter options
type TimeFilter = 'all' | 'today' | 'week' | 'month';
type ThreatTypeFilter = 'all' | 'cell_tower' | 'bluetooth' | 'network';

export default function ThreatMapScreen() {
  const insets = useSafeAreaInsets();
  const { threatLocations, currentLocation, clearThreatLocations } = useSecurity();
  
  const [timeFilter, setTimeFilter] = useState<TimeFilter>('all');
  const [typeFilter, setTypeFilter] = useState<ThreatTypeFilter>('all');
  const [selectedThreat, setSelectedThreat] = useState<ThreatLocation | null>(null);
  const [showDetailModal, setShowDetailModal] = useState(false);

  // Filter threats based on selected filters
  const filteredThreats = useMemo(() => {
    let filtered = [...threatLocations];
    
    // Time filter
    const now = Date.now();
    switch (timeFilter) {
      case 'today':
        filtered = filtered.filter(t => now - t.timestamp < 24 * 60 * 60 * 1000);
        break;
      case 'week':
        filtered = filtered.filter(t => now - t.timestamp < 7 * 24 * 60 * 60 * 1000);
        break;
      case 'month':
        filtered = filtered.filter(t => now - t.timestamp < 30 * 24 * 60 * 60 * 1000);
        break;
    }
    
    // Type filter
    if (typeFilter !== 'all') {
      filtered = filtered.filter(t => t.threatType === typeFilter);
    }
    
    return filtered;
  }, [threatLocations, timeFilter, typeFilter]);

  // Calculate map bounds based on threat locations
  const mapBounds = useMemo(() => {
    if (filteredThreats.length === 0) {
      // Default to San Francisco area
      return { minLat: 37.75, maxLat: 37.80, minLng: -122.45, maxLng: -122.39 };
    }
    
    const lats = filteredThreats.map(t => t.location.latitude);
    const lngs = filteredThreats.map(t => t.location.longitude);
    
    const minLat = Math.min(...lats) - 0.005;
    const maxLat = Math.max(...lats) + 0.005;
    const minLng = Math.min(...lngs) - 0.005;
    const maxLng = Math.max(...lngs) + 0.005;
    
    return { minLat, maxLat, minLng, maxLng };
  }, [filteredThreats]);

  // Stats
  const stats = useMemo(() => {
    const total = filteredThreats.length;
    const high = filteredThreats.filter(t => t.severity === 'high' || t.severity === 'critical').length;
    const cellTower = filteredThreats.filter(t => t.threatType === 'cell_tower').length;
    const bluetooth = filteredThreats.filter(t => t.threatType === 'bluetooth').length;
    return { total, high, cellTower, bluetooth };
  }, [filteredThreats]);

  const handleMarkerPress = (threat: ThreatLocation) => {
    setSelectedThreat(threat);
    setShowDetailModal(true);
  };

  return (
    <ThemedView style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <ThemedText type="title" style={styles.title}>Threat Map</ThemedText>
        <Pressable 
          style={styles.clearButton}
          onPress={clearThreatLocations}
        >
          <ThemedText style={styles.clearButtonText}>Clear All</ThemedText>
        </Pressable>
      </View>

      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 100 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Stats Row */}
        <View style={styles.statsRow}>
          <View style={styles.statItem}>
            <ThemedText style={styles.statValue}>{stats.total}</ThemedText>
            <ThemedText style={styles.statLabel}>Total</ThemedText>
          </View>
          <View style={styles.statItem}>
            <ThemedText style={[styles.statValue, { color: ThreatColors.high }]}>{stats.high}</ThemedText>
            <ThemedText style={styles.statLabel}>High Risk</ThemedText>
          </View>
          <View style={styles.statItem}>
            <ThemedText style={styles.statValue}>{stats.cellTower}</ThemedText>
            <ThemedText style={styles.statLabel}>Cell Tower</ThemedText>
          </View>
          <View style={styles.statItem}>
            <ThemedText style={styles.statValue}>{stats.bluetooth}</ThemedText>
            <ThemedText style={styles.statLabel}>Bluetooth</ThemedText>
          </View>
        </View>

        {/* Time Filter */}
        <View style={styles.filterSection}>
          <ThemedText style={styles.filterLabel}>Time Range</ThemedText>
          <View style={styles.filterRow}>
            {(['all', 'today', 'week', 'month'] as TimeFilter[]).map((filter) => (
              <Pressable
                key={filter}
                style={[
                  styles.filterChip,
                  timeFilter === filter && styles.filterChipActive,
                ]}
                onPress={() => setTimeFilter(filter)}
              >
                <ThemedText
                  style={[
                    styles.filterChipText,
                    timeFilter === filter && styles.filterChipTextActive,
                  ]}
                >
                  {filter === 'all' ? 'All Time' : filter.charAt(0).toUpperCase() + filter.slice(1)}
                </ThemedText>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Type Filter */}
        <View style={styles.filterSection}>
          <ThemedText style={styles.filterLabel}>Threat Type</ThemedText>
          <View style={styles.filterRow}>
            {(['all', 'cell_tower', 'bluetooth', 'network'] as ThreatTypeFilter[]).map((filter) => (
              <Pressable
                key={filter}
                style={[
                  styles.filterChip,
                  typeFilter === filter && styles.filterChipActive,
                ]}
                onPress={() => setTypeFilter(filter)}
              >
                <ThemedText
                  style={[
                    styles.filterChipText,
                    typeFilter === filter && styles.filterChipTextActive,
                  ]}
                >
                  {filter === 'all' ? 'All' : filter === 'cell_tower' ? '📡 Tower' : filter === 'bluetooth' ? '📱 BT' : '🌐 Net'}
                </ThemedText>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Map View */}
        <View style={styles.mapContainer}>
          <View style={styles.mapView}>
            {/* Grid lines */}
            {[...Array(5)].map((_, i) => (
              <View
                key={`h-${i}`}
                style={[
                  styles.gridLine,
                  { top: (MAP_HEIGHT / 4) * i, width: '100%', height: 1 },
                ]}
              />
            ))}
            {[...Array(5)].map((_, i) => (
              <View
                key={`v-${i}`}
                style={[
                  styles.gridLine,
                  { left: (MAP_WIDTH / 4) * i, height: '100%', width: 1 },
                ]}
              />
            ))}

            {/* Current location marker */}
            {currentLocation && (
              <View
                style={[
                  styles.currentLocationMarker,
                  {
                    left: latLngToMapCoords(
                      currentLocation.latitude,
                      currentLocation.longitude,
                      mapBounds
                    ).x - 12,
                    top: latLngToMapCoords(
                      currentLocation.latitude,
                      currentLocation.longitude,
                      mapBounds
                    ).y - 12,
                  },
                ]}
              >
                <View style={styles.currentLocationDot} />
                <View style={styles.currentLocationPulse} />
              </View>
            )}

            {/* Threat markers */}
            {filteredThreats.map((threat) => {
              const coords = latLngToMapCoords(
                threat.location.latitude,
                threat.location.longitude,
                mapBounds
              );
              return (
                <Pressable
                  key={threat.id}
                  style={[
                    styles.marker,
                    {
                      left: coords.x - 16,
                      top: coords.y - 16,
                      backgroundColor: getMarkerColor(threat.severity),
                    },
                  ]}
                  onPress={() => handleMarkerPress(threat)}
                >
                  <ThemedText style={styles.markerIcon}>
                    {getMarkerIcon(threat.threatType)}
                  </ThemedText>
                </Pressable>
              );
            })}

            {/* Empty state */}
            {filteredThreats.length === 0 && (
              <View style={styles.emptyMapState}>
                <ThemedText style={styles.emptyMapIcon}>🗺️</ThemedText>
                <ThemedText style={styles.emptyMapText}>No threats in selected range</ThemedText>
              </View>
            )}
          </View>

          {/* Map legend */}
          <View style={styles.legend}>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: ThreatColors.high }]} />
              <ThemedText style={styles.legendText}>High</ThemedText>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: ThreatColors.medium }]} />
              <ThemedText style={styles.legendText}>Medium</ThemedText>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: ThreatColors.low }]} />
              <ThemedText style={styles.legendText}>Low</ThemedText>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: Colors.dark.tint }]} />
              <ThemedText style={styles.legendText}>You</ThemedText>
            </View>
          </View>
        </View>

        {/* Recent Threats List */}
        <View style={styles.recentSection}>
          <ThemedText type="subtitle" style={styles.sectionTitle}>Recent Threats</ThemedText>
          {filteredThreats.slice(0, 10).map((threat) => (
            <Pressable
              key={threat.id}
              style={styles.threatItem}
              onPress={() => handleMarkerPress(threat)}
            >
              <View style={[styles.threatIcon, { backgroundColor: getMarkerColor(threat.severity) + '20' }]}>
                <ThemedText style={styles.threatIconText}>{getMarkerIcon(threat.threatType)}</ThemedText>
              </View>
              <View style={styles.threatInfo}>
                <ThemedText style={styles.threatTitle}>{threat.title}</ThemedText>
                <ThemedText style={styles.threatDescription} numberOfLines={1}>
                  {threat.description}
                </ThemedText>
              </View>
              <View style={styles.threatMeta}>
                <ThemedText style={styles.threatTime}>{formatTimeAgo(threat.timestamp)}</ThemedText>
                <View style={[styles.severityBadge, { backgroundColor: getMarkerColor(threat.severity) }]}>
                  <ThemedText style={styles.severityText}>{threat.severity}</ThemedText>
                </View>
              </View>
            </Pressable>
          ))}
        </View>
      </ScrollView>

      {/* Threat Detail Modal */}
      <Modal
        visible={showDetailModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowDetailModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { paddingBottom: insets.bottom + 20 }]}>
            {selectedThreat && (
              <>
                <View style={styles.modalHeader}>
                  <View style={[styles.modalIcon, { backgroundColor: getMarkerColor(selectedThreat.severity) + '20' }]}>
                    <ThemedText style={styles.modalIconText}>
                      {getMarkerIcon(selectedThreat.threatType)}
                    </ThemedText>
                  </View>
                  <Pressable
                    style={styles.closeButton}
                    onPress={() => setShowDetailModal(false)}
                  >
                    <ThemedText style={styles.closeButtonText}>✕</ThemedText>
                  </Pressable>
                </View>

                <ThemedText type="subtitle" style={styles.modalTitle}>
                  {selectedThreat.title}
                </ThemedText>

                <View style={[styles.severityBadgeLarge, { backgroundColor: getMarkerColor(selectedThreat.severity) }]}>
                  <ThemedText style={styles.severityTextLarge}>
                    {selectedThreat.severity.toUpperCase()} SEVERITY
                  </ThemedText>
                </View>

                <ThemedText style={styles.modalDescription}>
                  {selectedThreat.description}
                </ThemedText>

                <View style={styles.modalDetails}>
                  <View style={styles.detailRow}>
                    <ThemedText style={styles.detailLabel}>Type</ThemedText>
                    <ThemedText style={styles.detailValue}>
                      {selectedThreat.threatType.replace('_', ' ').toUpperCase()}
                    </ThemedText>
                  </View>
                  <View style={styles.detailRow}>
                    <ThemedText style={styles.detailLabel}>Detected</ThemedText>
                    <ThemedText style={styles.detailValue}>
                      {new Date(selectedThreat.timestamp).toLocaleString()}
                    </ThemedText>
                  </View>
                  <View style={styles.detailRow}>
                    <ThemedText style={styles.detailLabel}>Location</ThemedText>
                    <ThemedText style={styles.detailValue}>
                      {selectedThreat.location.latitude.toFixed(4)}, {selectedThreat.location.longitude.toFixed(4)}
                    </ThemedText>
                  </View>
                  {selectedThreat.location.accuracy && (
                    <View style={styles.detailRow}>
                      <ThemedText style={styles.detailLabel}>Accuracy</ThemedText>
                      <ThemedText style={styles.detailValue}>
                        ±{selectedThreat.location.accuracy.toFixed(0)}m
                      </ThemedText>
                    </View>
                  )}
                </View>

                <Pressable
                  style={styles.dismissButton}
                  onPress={() => setShowDetailModal(false)}
                >
                  <ThemedText style={styles.dismissButtonText}>Dismiss</ThemedText>
                </Pressable>
              </>
            )}
          </View>
        </View>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  title: {
    fontSize: 28,
    lineHeight: 34,
  },
  clearButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: 'rgba(255, 59, 92, 0.1)',
    borderRadius: 8,
  },
  clearButtonText: {
    color: ThreatColors.high,
    fontSize: 14,
    fontWeight: '500',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 16,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: Colors.dark.surface,
    paddingVertical: 12,
    marginHorizontal: 4,
    borderRadius: 12,
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: Colors.dark.tint,
  },
  statLabel: {
    fontSize: 11,
    color: Colors.dark.textSecondary,
    marginTop: 2,
  },
  filterSection: {
    marginBottom: 16,
  },
  filterLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.dark.textSecondary,
    marginBottom: 8,
  },
  filterRow: {
    flexDirection: 'row',
    gap: 8,
  },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    backgroundColor: Colors.dark.surface,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  filterChipActive: {
    backgroundColor: Colors.dark.tint + '20',
    borderColor: Colors.dark.tint,
  },
  filterChipText: {
    fontSize: 13,
    color: Colors.dark.textSecondary,
  },
  filterChipTextActive: {
    color: Colors.dark.tint,
    fontWeight: '600',
  },
  mapContainer: {
    marginBottom: 24,
  },
  mapView: {
    width: MAP_WIDTH,
    height: MAP_HEIGHT,
    backgroundColor: Colors.dark.surface,
    borderRadius: 16,
    overflow: 'hidden',
    position: 'relative',
  },
  gridLine: {
    position: 'absolute',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
  },
  currentLocationMarker: {
    position: 'absolute',
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  currentLocationDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: Colors.dark.tint,
    borderWidth: 2,
    borderColor: '#fff',
  },
  currentLocationPulse: {
    position: 'absolute',
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: Colors.dark.tint,
    opacity: 0.3,
  },
  marker: {
    position: 'absolute',
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  markerIcon: {
    fontSize: 16,
  },
  emptyMapState: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyMapIcon: {
    fontSize: 48,
    marginBottom: 12,
  },
  emptyMapText: {
    fontSize: 14,
    color: Colors.dark.textSecondary,
  },
  legend: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 16,
    marginTop: 12,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  legendDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  legendText: {
    fontSize: 12,
    color: Colors.dark.textSecondary,
  },
  recentSection: {
    marginBottom: 20,
  },
  sectionTitle: {
    marginBottom: 12,
  },
  threatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.dark.surface,
    padding: 12,
    borderRadius: 12,
    marginBottom: 8,
  },
  threatIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  threatIconText: {
    fontSize: 20,
  },
  threatInfo: {
    flex: 1,
    marginLeft: 12,
  },
  threatTitle: {
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 2,
  },
  threatDescription: {
    fontSize: 13,
    color: Colors.dark.textSecondary,
  },
  threatMeta: {
    alignItems: 'flex-end',
    marginLeft: 8,
  },
  threatTime: {
    fontSize: 12,
    color: Colors.dark.textSecondary,
    marginBottom: 4,
  },
  severityBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
  },
  severityText: {
    fontSize: 10,
    fontWeight: '700',
    color: '#fff',
    textTransform: 'uppercase',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: Colors.dark.surface,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  modalIcon: {
    width: 56,
    height: 56,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalIconText: {
    fontSize: 28,
  },
  closeButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeButtonText: {
    fontSize: 18,
    color: Colors.dark.textSecondary,
  },
  modalTitle: {
    fontSize: 22,
    marginBottom: 12,
  },
  severityBadgeLarge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
    marginBottom: 16,
  },
  severityTextLarge: {
    fontSize: 12,
    fontWeight: '700',
    color: '#fff',
  },
  modalDescription: {
    fontSize: 15,
    color: Colors.dark.textSecondary,
    lineHeight: 22,
    marginBottom: 20,
  },
  modalDetails: {
    backgroundColor: Colors.dark.background,
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.05)',
  },
  detailLabel: {
    fontSize: 14,
    color: Colors.dark.textSecondary,
  },
  detailValue: {
    fontSize: 14,
    fontWeight: '500',
  },
  dismissButton: {
    backgroundColor: Colors.dark.tint,
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  dismissButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.dark.background,
  },
});
