// Security Context - Global state for surveillance detection

import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  SecurityStatus,
  CellTower,
  BluetoothDevice,
  Alert,
  AppSettings,
  DEFAULT_SETTINGS,
  ThreatLevel,
  ThreatLocation,
  GeoLocation,
} from '@/types/security';
import {
  generateMockCellTower,
  generateThreatIndicators,
  calculateThreatLevel,
  generateMockBluetoothDevice,
  generateMockAlert,
  generateInitialMockData,
} from '@/lib/mock-data';

interface SecurityContextType {
  // State
  securityStatus: SecurityStatus;
  currentTower: CellTower | null;
  devices: BluetoothDevice[];
  alerts: Alert[];
  settings: AppSettings;
  isScanning: boolean;
  threatLocations: ThreatLocation[];
  currentLocation: GeoLocation | null;
  
  // Actions
  startScan: () => void;
  stopScan: () => void;
  refreshData: () => void;
  markDeviceKnown: (deviceId: string) => void;
  markDeviceIgnored: (deviceId: string) => void;
  markAlertRead: (alertId: string) => void;
  clearAlerts: () => void;
  updateSettings: (newSettings: Partial<AppSettings>) => void;
  simulateThreat: () => void;
  clearThreatLocations: () => void;
}

const SecurityContext = createContext<SecurityContextType | undefined>(undefined);

const STORAGE_KEYS = {
  DEVICES: 'sentinel_devices',
  ALERTS: 'sentinel_alerts',
  SETTINGS: 'sentinel_settings',
  THREAT_LOCATIONS: 'sentinel_threat_locations',
};

// Generate mock location data for demonstration
const generateMockLocation = (): GeoLocation => {
  // Generate locations around a central point (simulating user movement)
  const baseLat = 37.7749; // San Francisco
  const baseLng = -122.4194;
  const variance = 0.02; // ~2km radius
  
  return {
    latitude: baseLat + (Math.random() - 0.5) * variance,
    longitude: baseLng + (Math.random() - 0.5) * variance,
    accuracy: Math.random() * 20 + 5,
    timestamp: Date.now(),
  };
};

// Generate initial mock threat locations
const generateInitialThreatLocations = (): ThreatLocation[] => {
  const threatTypes: ThreatLocation['threatType'][] = ['cell_tower', 'bluetooth', 'network'];
  const severities: ThreatLevel[] = ['low', 'medium', 'high'];
  const titles = {
    cell_tower: ['2G Downgrade Detected', 'Suspicious Tower ID', 'IMSI Request'],
    bluetooth: ['Unknown Tracker', 'Suspicious Device', 'AirTag Detected'],
    network: ['Encryption Disabled', 'Unusual Traffic', 'Man-in-the-Middle'],
  };
  
  return Array.from({ length: 8 }, (_, i) => {
    const threatType = threatTypes[i % 3];
    const severity = severities[Math.floor(Math.random() * 3)];
    const titleOptions = titles[threatType];
    
    return {
      id: Math.random().toString(36).substring(2, 15),
      location: {
        latitude: 37.7749 + (Math.random() - 0.5) * 0.04,
        longitude: -122.4194 + (Math.random() - 0.5) * 0.04,
        accuracy: Math.random() * 20 + 5,
        timestamp: Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000, // Last 7 days
      },
      threatType,
      severity,
      title: titleOptions[Math.floor(Math.random() * titleOptions.length)],
      description: `Threat detected at this location. Severity: ${severity}`,
      timestamp: Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000,
    };
  });
};

export function SecurityProvider({ children }: { children: ReactNode }) {
  const [securityStatus, setSecurityStatus] = useState<SecurityStatus>({
    overallThreat: 'safe',
    activeThreats: 0,
    lastScanTime: Date.now(),
    isScanning: false,
    indicators: [],
  });
  const [currentTower, setCurrentTower] = useState<CellTower | null>(null);
  const [devices, setDevices] = useState<BluetoothDevice[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [isScanning, setIsScanning] = useState(false);
  const [threatLocations, setThreatLocations] = useState<ThreatLocation[]>([]);
  const [currentLocation, setCurrentLocation] = useState<GeoLocation | null>(null);

  // Load saved data on mount
  useEffect(() => {
    loadSavedData();
  }, []);

  const loadSavedData = async () => {
    try {
      const [savedDevices, savedAlerts, savedSettings, savedThreatLocations] = await Promise.all([
        AsyncStorage.getItem(STORAGE_KEYS.DEVICES),
        AsyncStorage.getItem(STORAGE_KEYS.ALERTS),
        AsyncStorage.getItem(STORAGE_KEYS.SETTINGS),
        AsyncStorage.getItem(STORAGE_KEYS.THREAT_LOCATIONS),
      ]);

      if (savedDevices) setDevices(JSON.parse(savedDevices));
      if (savedAlerts) setAlerts(JSON.parse(savedAlerts));
      if (savedSettings) setSettings({ ...DEFAULT_SETTINGS, ...JSON.parse(savedSettings) });
      
      if (savedThreatLocations) {
        setThreatLocations(JSON.parse(savedThreatLocations));
      } else {
        // Initialize with mock threat locations
        const initialThreatLocations = generateInitialThreatLocations();
        setThreatLocations(initialThreatLocations);
      }

      // Initialize with mock data if empty
      if (!savedDevices && !savedAlerts) {
        const initialData = generateInitialMockData();
        setCurrentTower(initialData.tower);
        setSecurityStatus(initialData.securityStatus);
        setDevices(initialData.devices);
        setAlerts(initialData.alerts);
      }
      
      // Set initial mock location
      setCurrentLocation(generateMockLocation());
    } catch (error) {
      console.error('Error loading saved data:', error);
      // Initialize with mock data on error
      const initialData = generateInitialMockData();
      setCurrentTower(initialData.tower);
      setSecurityStatus(initialData.securityStatus);
      setDevices(initialData.devices);
      setAlerts(initialData.alerts);
      setThreatLocations(generateInitialThreatLocations());
      setCurrentLocation(generateMockLocation());
    }
  };

  // Save data when it changes
  useEffect(() => {
    AsyncStorage.setItem(STORAGE_KEYS.DEVICES, JSON.stringify(devices));
  }, [devices]);

  useEffect(() => {
    AsyncStorage.setItem(STORAGE_KEYS.ALERTS, JSON.stringify(alerts));
  }, [alerts]);

  useEffect(() => {
    AsyncStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    AsyncStorage.setItem(STORAGE_KEYS.THREAT_LOCATIONS, JSON.stringify(threatLocations));
  }, [threatLocations]);

  // Add threat location when a threat is detected
  const addThreatLocation = useCallback((
    threatType: ThreatLocation['threatType'],
    severity: ThreatLevel,
    title: string,
    description: string,
    alertId?: string
  ) => {
    const location = currentLocation || generateMockLocation();
    
    const newThreatLocation: ThreatLocation = {
      id: Math.random().toString(36).substring(2, 15),
      location: { ...location, timestamp: Date.now() },
      threatType,
      severity,
      title,
      description,
      timestamp: Date.now(),
      relatedAlertId: alertId,
    };
    
    setThreatLocations(prev => [newThreatLocation, ...prev].slice(0, 200)); // Keep last 200 locations
  }, [currentLocation]);

  const startScan = useCallback(() => {
    setIsScanning(true);
    setSecurityStatus(prev => ({ ...prev, isScanning: true }));
    
    // Update mock location periodically
    const locationInterval = setInterval(() => {
      setCurrentLocation(generateMockLocation());
    }, 10000); // Update every 10 seconds
    
    // Simulate scanning process
    const scanInterval = setInterval(() => {
      // Generate new tower data
      const newTower = generateMockCellTower(Math.random() < 0.1); // 10% chance of anomaly
      const indicators = generateThreatIndicators(newTower);
      const threatLevel = calculateThreatLevel(indicators);
      
      setCurrentTower(newTower);
      setSecurityStatus({
        overallThreat: threatLevel,
        activeThreats: indicators.length,
        lastScanTime: Date.now(),
        isScanning: true,
        indicators,
      });
      
      // Occasionally add new devices
      if (Math.random() < 0.3) {
        const newDevice = generateMockBluetoothDevice(
          Math.random() < 0.05, // 5% chance of tracker
          Math.random() < 0.1  // 10% chance of suspicious
        );
        setDevices(prev => {
          // Don't add duplicates
          if (prev.some(d => d.macAddress === newDevice.macAddress)) {
            return prev.map(d => 
              d.macAddress === newDevice.macAddress 
                ? { ...d, lastSeen: Date.now(), sightingCount: d.sightingCount + 1 }
                : d
            );
          }
          return [...prev, newDevice].slice(-50); // Keep last 50 devices
        });
      }
      
      // Generate alerts for threats and add to threat locations
      if (indicators.length > 0 && Math.random() < 0.5) {
        const alertType = Math.random() < 0.5 ? 'cell_tower' : 'bluetooth';
        const newAlert = generateMockAlert(alertType, threatLevel);
        setAlerts(prev => [newAlert, ...prev].slice(0, 100)); // Keep last 100 alerts
        
        // Add threat location
        const location = generateMockLocation();
        const newThreatLocation: ThreatLocation = {
          id: Math.random().toString(36).substring(2, 15),
          location: { ...location, timestamp: Date.now() },
          threatType: alertType as ThreatLocation['threatType'],
          severity: threatLevel,
          title: newAlert.title,
          description: newAlert.message,
          timestamp: Date.now(),
          relatedAlertId: newAlert.id,
        };
        setThreatLocations(prev => [newThreatLocation, ...prev].slice(0, 200));
      }
    }, settings.scanIntervalSeconds * 1000);
    
    // Store interval IDs for cleanup
    (window as any).scanInterval = scanInterval;
    (window as any).locationInterval = locationInterval;
  }, [settings.scanIntervalSeconds]);

  const stopScan = useCallback(() => {
    setIsScanning(false);
    setSecurityStatus(prev => ({ ...prev, isScanning: false }));
    
    if ((window as any).scanInterval) {
      clearInterval((window as any).scanInterval);
    }
    if ((window as any).locationInterval) {
      clearInterval((window as any).locationInterval);
    }
  }, []);

  const refreshData = useCallback(() => {
    const newTower = generateMockCellTower(Math.random() < 0.15);
    const indicators = generateThreatIndicators(newTower);
    const threatLevel = calculateThreatLevel(indicators);
    
    setCurrentTower(newTower);
    setSecurityStatus({
      overallThreat: threatLevel,
      activeThreats: indicators.length,
      lastScanTime: Date.now(),
      isScanning,
      indicators,
    });
    
    // Update location on refresh
    setCurrentLocation(generateMockLocation());
  }, [isScanning]);

  const markDeviceKnown = useCallback((deviceId: string) => {
    setDevices(prev => prev.map(d => 
      d.id === deviceId ? { ...d, isKnown: true, riskLevel: 'low' as const } : d
    ));
  }, []);

  const markDeviceIgnored = useCallback((deviceId: string) => {
    setDevices(prev => prev.map(d => 
      d.id === deviceId ? { ...d, isIgnored: true } : d
    ));
  }, []);

  const markAlertRead = useCallback((alertId: string) => {
    setAlerts(prev => prev.map(a => 
      a.id === alertId ? { ...a, isRead: true } : a
    ));
  }, []);

  const clearAlerts = useCallback(() => {
    setAlerts([]);
  }, []);

  const updateSettings = useCallback((newSettings: Partial<AppSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  }, []);

  const clearThreatLocations = useCallback(() => {
    setThreatLocations([]);
  }, []);

  const simulateThreat = useCallback(() => {
    // Force generate a threat scenario
    const threatTower = generateMockCellTower(true);
    const indicators = generateThreatIndicators(threatTower);
    
    // Add additional threat indicators
    indicators.push({
      id: Math.random().toString(36).substring(2, 15),
      type: 'imsi_request',
      severity: 'high',
      title: 'IMSI Request Detected',
      description: 'The tower requested your IMSI identifier, which is a common surveillance technique.',
      timestamp: Date.now(),
    });
    
    setCurrentTower(threatTower);
    setSecurityStatus({
      overallThreat: 'high',
      activeThreats: indicators.length,
      lastScanTime: Date.now(),
      isScanning,
      indicators,
    });
    
    // Add threat alert
    const threatAlert = generateMockAlert('cell_tower', 'high');
    setAlerts(prev => [threatAlert, ...prev]);
    
    // Add suspicious tracker
    const tracker = generateMockBluetoothDevice(true, true);
    setDevices(prev => [tracker, ...prev]);
    
    // Add threat location for the simulated threat
    const location = generateMockLocation();
    const newThreatLocation: ThreatLocation = {
      id: Math.random().toString(36).substring(2, 15),
      location: { ...location, timestamp: Date.now() },
      threatType: 'cell_tower',
      severity: 'high',
      title: 'IMSI Catcher Detected',
      description: 'A fake cell tower was detected at this location attempting to intercept communications.',
      timestamp: Date.now(),
      relatedAlertId: threatAlert.id,
    };
    setThreatLocations(prev => [newThreatLocation, ...prev]);
  }, [isScanning]);

  return (
    <SecurityContext.Provider
      value={{
        securityStatus,
        currentTower,
        devices,
        alerts,
        settings,
        isScanning,
        threatLocations,
        currentLocation,
        startScan,
        stopScan,
        refreshData,
        markDeviceKnown,
        markDeviceIgnored,
        markAlertRead,
        clearAlerts,
        updateSettings,
        simulateThreat,
        clearThreatLocations,
      }}
    >
      {children}
    </SecurityContext.Provider>
  );
}

export function useSecurity() {
  const context = useContext(SecurityContext);
  if (context === undefined) {
    throw new Error('useSecurity must be used within a SecurityProvider');
  }
  return context;
}
