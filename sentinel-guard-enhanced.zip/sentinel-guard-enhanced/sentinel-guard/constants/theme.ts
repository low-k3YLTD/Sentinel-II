/**
 * Sentinel Guard Theme Configuration
 * Dark-first design with cyber security aesthetic
 */

import { Platform } from "react-native";

// Sentinel Guard Color Palette
export const Colors = {
  light: {
    text: "#11181C",
    textSecondary: "#687076",
    textDisabled: "#9CA3AF",
    background: "#F8FAFC",
    surface: "#FFFFFF",
    surfaceElevated: "#F1F5F9",
    tint: "#00A88A",
    icon: "#687076",
    tabIconDefault: "#687076",
    tabIconSelected: "#00A88A",
    // Status colors
    safe: "#00D4AA",
    warning: "#FFB800",
    danger: "#FF3B5C",
    info: "#3B82F6",
    // Accent
    accent: "#00D4AA",
    accentSecondary: "#6366F1",
    // Borders
    border: "#E2E8F0",
    borderLight: "#F1F5F9",
  },
  dark: {
    text: "#FFFFFF",
    textSecondary: "#9CA3AF",
    textDisabled: "#4B5563",
    background: "#0D0D0F",
    surface: "#1A1A1E",
    surfaceElevated: "#252529",
    tint: "#00D4AA",
    icon: "#9CA3AF",
    tabIconDefault: "#6B7280",
    tabIconSelected: "#00D4AA",
    // Status colors
    safe: "#00D4AA",
    warning: "#FFB800",
    danger: "#FF3B5C",
    info: "#3B82F6",
    // Accent
    accent: "#00D4AA",
    accentSecondary: "#6366F1",
    // Borders
    border: "#2D2D32",
    borderLight: "#1F1F23",
  },
};

// Threat level colors (consistent across themes)
export const ThreatColors = {
  safe: "#00D4AA",
  low: "#3B82F6",
  medium: "#FFB800",
  high: "#FF3B5C",
  critical: "#DC2626",
};

// Bluetooth device risk colors
export const RiskColors = {
  low: "#00D4AA",
  medium: "#FFB800",
  high: "#FF3B5C",
  unknown: "#6B7280",
};

export const Fonts = Platform.select({
  ios: {
    sans: "system-ui",
    serif: "ui-serif",
    rounded: "ui-rounded",
    mono: "ui-monospace",
  },
  default: {
    sans: "normal",
    serif: "serif",
    rounded: "normal",
    mono: "monospace",
  },
  web: {
    sans: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
    serif: "Georgia, 'Times New Roman', serif",
    rounded: "'SF Pro Rounded', 'Hiragino Maru Gothic ProN', Meiryo, 'MS PGothic', sans-serif",
    mono: "SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
  },
});

// Spacing scale (8pt grid)
export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  xxxl: 48,
};

// Border radius
export const Radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 9999,
};
