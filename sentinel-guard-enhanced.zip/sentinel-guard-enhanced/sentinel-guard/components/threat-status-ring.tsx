// Animated threat status ring component

import React, { useEffect, useState } from 'react';
import { View, StyleSheet } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  withSequence,
  Easing,
  runOnJS,
} from 'react-native-reanimated';
import Svg, { Circle, Defs, LinearGradient, Stop } from 'react-native-svg';
import { ThemedText } from './themed-text';
import { IconSymbol } from './ui/icon-symbol';
import { ThreatColors } from '@/constants/theme';
import { ThreatLevel } from '@/types/security';

interface ThreatStatusRingProps {
  threatLevel: ThreatLevel;
  isScanning: boolean;
  size?: number;
}

const THREAT_CONFIG: Record<ThreatLevel, { label: string; icon: string; color: string }> = {
  safe: { label: 'SECURE', icon: 'checkmark.shield.fill', color: ThreatColors.safe },
  low: { label: 'LOW RISK', icon: 'info.circle.fill', color: ThreatColors.low },
  medium: { label: 'CAUTION', icon: 'exclamationmark.triangle.fill', color: ThreatColors.medium },
  high: { label: 'WARNING', icon: 'exclamationmark.shield.fill', color: ThreatColors.high },
  critical: { label: 'DANGER', icon: 'xmark.shield.fill', color: ThreatColors.critical },
};

export function ThreatStatusRing({ threatLevel, isScanning, size = 200 }: ThreatStatusRingProps) {
  const config = THREAT_CONFIG[threatLevel];
  const strokeWidth = 12;
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  
  // State for progress
  const [progressOffset, setProgressOffset] = useState(circumference);
  
  // Animation values
  const rotation = useSharedValue(0);
  const pulse = useSharedValue(1);

  useEffect(() => {
    // Rotation animation when scanning
    if (isScanning) {
      rotation.value = withRepeat(
        withTiming(360, { duration: 3000, easing: Easing.linear }),
        -1,
        false
      );
    } else {
      rotation.value = withTiming(0, { duration: 500 });
    }
  }, [isScanning]);

  useEffect(() => {
    // Pulse animation based on threat level
    const pulseIntensity = threatLevel === 'safe' ? 0 : 
                          threatLevel === 'low' ? 0.02 :
                          threatLevel === 'medium' ? 0.04 :
                          threatLevel === 'high' ? 0.06 : 0.08;
    
    if (pulseIntensity > 0) {
      pulse.value = withRepeat(
        withSequence(
          withTiming(1 + pulseIntensity, { duration: 1000 }),
          withTiming(1, { duration: 1000 })
        ),
        -1,
        true
      );
    } else {
      pulse.value = withTiming(1, { duration: 300 });
    }
  }, [threatLevel]);

  useEffect(() => {
    // Update progress based on threat level
    const targetProgress = threatLevel === 'safe' ? 1 :
                          threatLevel === 'low' ? 0.85 :
                          threatLevel === 'medium' ? 0.65 :
                          threatLevel === 'high' ? 0.4 : 0.2;
    
    setProgressOffset(circumference * (1 - targetProgress));
  }, [threatLevel, circumference]);

  const containerStyle = useAnimatedStyle(() => ({
    transform: [
      { rotate: `${rotation.value}deg` },
      { scale: pulse.value },
    ],
  }));

  return (
    <View style={[styles.container, { width: size, height: size }]}>
      <Animated.View style={[styles.ringContainer, containerStyle]}>
        <Svg width={size} height={size}>
          <Defs>
            <LinearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <Stop offset="0%" stopColor={config.color} stopOpacity="1" />
              <Stop offset="100%" stopColor={config.color} stopOpacity="0.5" />
            </LinearGradient>
          </Defs>
          
          {/* Background circle */}
          <Circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="rgba(255, 255, 255, 0.1)"
            strokeWidth={strokeWidth}
            fill="none"
          />
          
          {/* Progress circle */}
          <Circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={config.color}
            strokeWidth={strokeWidth}
            fill="none"
            strokeLinecap="round"
            strokeDasharray={`${circumference}`}
            strokeDashoffset={progressOffset}
            rotation={-90}
            origin={`${size / 2}, ${size / 2}`}
          />
        </Svg>
      </Animated.View>
      
      {/* Center content */}
      <View style={styles.centerContent}>
        <IconSymbol
          name={config.icon as any}
          size={48}
          color={config.color}
        />
        <ThemedText style={[styles.statusLabel, { color: config.color }]}>
          {config.label}
        </ThemedText>
        {isScanning && (
          <ThemedText style={styles.scanningText}>Scanning...</ThemedText>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  ringContainer: {
    position: 'absolute',
  },
  centerContent: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusLabel: {
    fontSize: 18,
    fontWeight: '700',
    marginTop: 8,
    letterSpacing: 2,
  },
  scanningText: {
    fontSize: 12,
    color: '#9CA3AF',
    marginTop: 4,
  },
});
