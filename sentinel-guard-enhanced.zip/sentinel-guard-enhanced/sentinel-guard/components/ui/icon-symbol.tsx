// Fallback for using MaterialIcons on Android and web.

import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type MaterialIconName = ComponentProps<typeof MaterialIcons>["name"];

/**
 * Sentinel Guard Icon Mappings
 * SF Symbols to Material Icons
 */
const MAPPING: Record<string, MaterialIconName> = {
  // Tab bar icons
  "house.fill": "home",
  "shield.fill": "security",
  "antenna.radiowaves.left.and.right": "cell-tower",
  "dot.radiowaves.left.and.right": "bluetooth-searching",
  "bell.badge.fill": "notifications",
  "gearshape.fill": "settings",
  // Navigation
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "chevron.left": "chevron-left",
  "xmark": "close",
  // Status icons
  "checkmark.shield.fill": "verified-user",
  "exclamationmark.triangle.fill": "warning",
  "exclamationmark.shield.fill": "gpp-maybe",
  "xmark.shield.fill": "gpp-bad",
  // Cell tower icons
  "cellularbars": "signal-cellular-alt",
  "antenna.radiowaves.left.and.right.slash": "signal-cellular-off",
  "network": "lan",
  "location.fill": "location-on",
  "map.fill": "map",
  // Bluetooth icons
  "bluetooth": "bluetooth",
  "bluetooth.slash": "bluetooth-disabled",
  "wave.3.right": "wifi-tethering",
  // Alert icons
  "bell.fill": "notifications-active",
  "bell.slash.fill": "notifications-off",
  "info.circle.fill": "info",
  // Action icons
  "play.fill": "play-arrow",
  "stop.fill": "stop",
  "arrow.clockwise": "refresh",
  "square.and.arrow.up": "share",
  "trash.fill": "delete",
  "eye.fill": "visibility",
  "eye.slash.fill": "visibility-off",
  // Device icons
  "iphone": "smartphone",
  "laptopcomputer": "laptop",
  "headphones": "headphones",
  "applewatch": "watch",
  "airpods": "earbuds",
  "car.fill": "directions-car",
  "tag.fill": "sell",
  "questionmark.circle.fill": "help",
  // Misc
  "clock.fill": "schedule",
  "calendar": "calendar-today",
  "chart.bar.fill": "bar-chart",
  "list.bullet": "list",
  "slider.horizontal.3": "tune",
  "paperplane.fill": "send",
};

type IconSymbolName = keyof typeof MAPPING;

/**
 * An icon component that uses native SF Symbols on iOS, and Material Icons on Android and web.
 */
export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  const iconName = MAPPING[name] || "help";
  return <MaterialIcons color={color} size={size} name={iconName} style={style} />;
}

export type { IconSymbolName };
